<?php 
    $path = get_template_directory_uri();
    $path = $path.'/Module/Sidebar/sidebar_2_1_0'; 
    if($check == 0){
        $css_inline .= '
		<style>
			@media (max-width: 414px) {
				.pc {
					display: none;
				}
			}
		
			.mb {
				display: none;
			}
		
			@media (max-width: 414px) {
				.mb {
					display: block;
				}
			}
		
			.sidebar_2_1_0_item-2 .owl-carousel {
				display: block;
				text-align: center;
			}
		
			.sidebar_2_1_0_item-2 .owl-carousel img {
				width: 100%;
				margin-bottom: 10px;
			}
		
			.sidebar_2_1_0_item-2 .owl-carousel .owl-dots {
				display: block;
			}
		
			.sidebar_2_1_0_item-2 .owl-carousel span {
				color: #E04646;
				font-weight: 500;
			}
		
			.sidebar_2_1_0_item-2 .owl-theme .owl-dots .owl-dot.active span,
			.sidebar_2_1_0_item-2 .owl-theme .owl-dots .owl-dot:hover span {
				background: #002c96;
			}
		
			.sidebar_2_1_0_item-4 ul {
				list-style: none;
				padding-left: 0;
			}
		
			.sidebar_2_1_0_item-4 ul li {
				padding: 10px 0 10px 20px;
				border-bottom: 1px solid #ccc;
			}
		
			.sidebar_2_1_0_item-4 ul li:hover a {
				font-weight: 600;
				color: #002E60;
			}
		
			.sidebar_2_1_0_item-6 .uu-dai img {
				width: 100%;
				margin-bottom: 10px;
			}
		
			.sidebar_2_1_0_item-6 .uu-dai span {
				margin-bottom: 15px;
				display: block;
			}
		
			.sidebar_2_1_0_item-7 .siderbar_news-item {
				display: flex;
				margin-top: 15px;
				flex-wrap: wrap;
			}
		
			.sidebar_2_1_0_item-7 .siderbar_news-item .img {
				padding-right: 10px;
				width: 40%;
			}
		
			.sidebar_2_1_0_item-7 .siderbar_news-item .img img {
				width: 100%;
			}
		
			.sidebar_2_1_0_item-7 .siderbar_news-item .tt {
				font-size: 14px;
				width: 60%;
				flex: 1;
			}
		
			.sidebar_2_1_0_item-7 .siderbar_news-item .tt .more {
				color: #21A1ED;
				font-style: italic;
				padding: 5px 15px 0 0;
				font-size: 12px;
			}
		
			.sidebar_2_1_0_item-7 .siderbar_news-item .tt:hover a {
				color: #002E60;
			}
		
			.sidebar_2_1_0_tt {
				width: 100%;
				display: flex;
				background-color: #21A1ED;
				color: #fff;
				text-transform: uppercase;
				font-weight: 500;
				padding: 6px 0;
				margin-bottom: 6px;
				font-size: 14px;
			}
		
			.sidebar_2_1_0_tt p {
				padding-top: 6px;
				margin: 0;
			}
		
			.sidebar_2_1_0_icon {
				background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAADrCAYAAAAbgtR3AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyFpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDE0IDc5LjE1MTQ4MSwgMjAxMy8wMy8xMy0xMjowOToxNSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDoxQjE3OTNFMzhCMjUxMUU5OUNGMUQyMzFCNkY1NkIzRiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDoxQjE3OTNFNDhCMjUxMUU5OUNGMUQyMzFCNkY1NkIzRiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjFCMTc5M0UxOEIyNTExRTk5Q0YxRDIzMUI2RjU2QjNGIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjFCMTc5M0UyOEIyNTExRTk5Q0YxRDIzMUI2RjU2QjNGIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+wtd4lQAAE6lJREFUeNrsXQt4FcUVnjwISAivIC8VRVERgoJSIgSQp4ASFFFBigpapK0gqAhapYK2olZRLAiKCiJaESE+ABXfGl4SERAChqcRkAAlhAQJ5LGd8+Wf5jDO7t29926C7Z3v+7+7OzM7e+48z/xzZjbKsiwRpOshMUWivou4KyWGSRz2+pKoIAVsIbFJYodEFvyOSOySoARjJZpLxCCst8Q2iQsQ7trFBpl7XfF7nuY/UKKxxDqJscz/FolXJWpK5FWEgMfxW0ciVxOCp12C69PwG+31RdFBCliqCUI52V5ip0Qn+PeUOEeL77k+BZuDylHuzZG4FffvS+zF9Qf4TZbYEuwLokXo7iqJNRKdJYai4VyEHCT3O4kTwSYeGwYBqRWnSMyUeEviBYnpEs0QvjOUxEPNwQSJ30sMkTiIHKwn0U1irsQAiWXoXio0By3WOn8E4iRekViEsAksfp2KbiT78Luf+VEXc7HEWRIvafGz8Zvn9UVeRxJqCPdIXC7RQOIbiWOUDl6ei2pTjC4mFl1MS4lEidUS6yUmsdYeVgEtFGc6XsCHM8E65ij8gXgMcVQvN0o0kkiVWIGGFZZGQiNEpsTPrFo0lLgMAlRjiAeobt6AnDsKYagKVEcaHSS2S3wmcWEodbA3El4H5WA+cqYmwquwP1mCoo1CsdaV2MPC4zFEzkK/SMK3RbFTvc03l5ksYgdMt8qc8AmXI/02dnECFXEBu6ZK/olEIUCq1V2szs1GX1iIxjIfxU7udhSpevZLTbMpsa/1zv9wMsvBO3H9MrCThTXF9ecSL0ksxX07hJ+QyMFzLyFsuEQdXLeyk8FLP9gA//R23F8rkYbr6pqeqFp8PKurj2AIJHe9xJno3MPWUe9Gl/IuXp5iqArfoRtqgHtV8X+ReIIpELUwRheFcyz+l8QCdBEp6HZuRhgJ9RAEb4kcfUwiA+FDmFKRgj85n+mLIhx10Amn2fhXlYhyeC41UB0MVZu5Fa3yF+SehZxV14Wot6MCTB180QdjoU2no7ioq2kqcbfEixLfQ8heEs8hbr53vSn4Io5H2HXMryb8zmV+7eDXyJDGlX4WsZoINWJ+ahrKK/9ZATvjEFrxfoewY/jdo6n/AqOGcrsc0tqB3x+81MFxEmfgH18Dv6moT1GsE45jmnNnhDWB3ww2k7sUvy+DfeDKRQtcz2OKRQ66KFt9cDkSLYXmfECilU0RbwKTkMhydRsaSw2mRWdjpqdnSD5y+HyM29FIs22o3EyFuWhxiruIgBEBIwJWgIC1oBwcZVoMx8RQEo8Nwx9Mg6pPo8QGjX+5xJVS6qOAV0G4NLBcx2xIpkor4p5s/D7mR/2ODkP9Exh/7YQXfhRxVeh2cZpqdMQm/hfafRy4m0AukemLArO8zJOqho2Wu9/6tfvUEHeOZe8O4HeO4TlSUp6TKDE8d7PTxD0RU0uacH+MyZCakCc65ERT7b4Yk6dim/i3YyK1DxyjherSRX9PrIHNIs7kTonnmf/6AFTwTwaVPsahJQ9Ev3kJ07TbSKwNVAdPx281UBvkaoOo3Gx4UTZLPEMLa6PF0d9zECSAcle7mdWNcahT6wx1Sc3YPpSIYf4x8OMEEsc6h/eMcUMevQFVX6n2g2zibQAB2Qt1dhr8R6LerkYck6McfJ3dU9UaFigHR+JfdNb8d0hksPvTJWZKHLUCu6OIezp7PgNp8nd0RvyRTvPijYzsUS4FrVSFJYESHoF+aytjsF4FVOvfipY8As8ksfc01RiyIZoMxhxsLVGAf7JIYorEYdw/LFFfYhfuKawGGIa18PsLYMEvHnGeht8upPEw7g8jnUW4L4AM/5VJXVAi810U13H8PqL9MaI1slm8bAPVMUlLw8nNh0xC9eofIGAzGx0KJTbi+luJNFxnSkQbWmaSRB6QZAiPldiENNKQpoV3FOL6VchgQaYoevAmeCwBn0d+z7N/Q1x0A4neuL/LgWxq5UQESYxGGr2R5k72nucZp7gEfjdRNzMcPN4wxteNAo3RATpfDphTcrTMOkZrXMTJLGWctJ1bjl9K60OkvRwrT6MYZzgMrO1wgYq5xKZIarP7iQ515hDiLAfscvAcxJ/I/GrjXXpckqkgFv/6gOHfUvdgsnN5VOKQ5peJ39FBqHx2tjQkU3wwKv8rjFLTXUa4Z3VRVhl7lGszqHPXEMsLm0XwNghxYLlyRPmas52jNlCHBMzWtNpTyf0Uod8iAkYErCABaR49Hsx+KX7Hwz80F+KSfgwWBDPZsPcLu85EeEyw7whWsF4SCzEGK7dSIhnhybjnY/VCPOe7gDPZi4kZ+EpisGHZNQr+X2oMwkw/BeyHlxA1codEIgsjVb6vxFCJq3GvwhJho6AolX5+CagUyf7M73xoyDrPUgL/Zixuf4QtdftOL0NdDJQKeqAuqA4yVSZrtwSEkRK6F8tjRKPUASNGZnqfgMlQqlod4WYF1EPuqXnrO7i/SCIffk9JVNfiV4e/hXjN4f+Ozdw75CJ+FwkPw/1HBu3YhImMHhF43kJ6YROwOxIlNiBOogXr5+z6uD9LvIJw1U+2wPM7cN89XAIuRoKDNZJpvE38TmgkeRBovEYMDcb94nAJWICXqdx6hk0fla3CWkzOaRL0I8JvRXhvxkaoESgP6Tq+O9pDCy5iZGQMY77IVQGn/VcwWqSuzxfllumlGh9pIb2YcCkL6aBm+2qkpJor/1uiD5YiLkD4H9nzLbXnrkZ66eHqZvppjaI1IzX5ENcNlEYHbchThGVr0Caq0aSGs5v5VGsoK3A/OsBziu5YoTWQT8LdD/ZAwm/j/jKQPiVopbEGZuJ+hBcivmAsWo9wD3VxGKZoTlwPFZ8MaechjCbz74ky8xIya+mHhcQTICcXoM4fRPy6rubXHpWFj/Hvr2R+lDPpNpxNOss5bgr1sV/azCDGlPZDJ6zCmmMYG4ff5iwsDvEV3TbILwGpSizQCHIa/Hs61NsFjFa2cB/lp0Ydwzhn7hZDN6Q45zHlgrunbdjZsApIL/iOKa40nO1mSup2JtAeiduYorrO6wQqGAHvMKhL8ejvlHlyHmwPEwzq2ggv7/NKHtUG3VsLC4GNsSayCuHroF0nsRV42tNERre7sQZyBMNhrh/z4iHIhR+1ZQdaHaonUYr7CZpxuNIlt+J6iF9FnKRNjtKx7kEjxV/hVwy/QSxslTaZutjPOtgNwqhVzPFaS/2ndn8f4rXHClN3qwKYBb3beRPFS+N0NdZXvhUK7RFMI4nQbxEBK0LAJrDFanNKSGhoOXPRAj/zcS9T0N1ML0avWViqPSUEJIrs7xBqPfi8ZWyynVTZAir3vY2Kb2kdcx2PL6qqLe16FnA8m6veC79rcf8T2NELwTNz9z6mkXUNibfE0JbF4h/BlMBOoEaB6uB0ZrHGmdBz2Etek3gcwumL2qtQRSzNwGKGxBPMOmSlQbiLoUjcE2gs/k5bRY/D/VbNOEehK8ikDRK5EvtQf0dB9dfj38iMJvikii9lNHESsBf+ibLj+wYPxYWx8j+INGnmN1DiZ4ljIOAzoKLNctJmzmB1gtxUH1qoqkIvshLi1F6RG3VrLCI39EHA15B2LNu+plapJnHDHid8i+L2o4/rCWEu00imz7worKSErnEIp+6lI5RUPewCjYazM1G5h5ECf8NzrgW0M5JVuJ6R43rYogC7GhMQPj1YCrgKfp129i+DOXKWIWwMpqZ27hibygZlKl+q8dEmd8RkGMvoXidTl2JmwBOUwqqWqeoF0NgGSzwsyve9K6PIZ0X5Nl7dkdHuHbhu7GgCHaAOHscI4WYlycIu7GPs/lwtbheJbTZc4msmhSKQgKtcbt9th+3hNEx+jf4zQYtzH7OypJZ7KdS8rhg11KQ+yYuAii2oH2Kfp4jPNwPEy0W8qm4FbIsHbgxBuNOQRpZDnHp4xw0aUS/cMKrkVocg4J3aiKFjMKuHKczWtYZb6kPZt0YHKWC6Qz3uzWxkmzPuh1wftwK2Npmw2wx73Qym8a2hjQto2GO1kSrb5n1DvZBHOehyAhWjxepbE6ayDUHFX8mmEW/huqnNxvyuXgTsgofuNoT1ZRpyN0Zy7kP4Degb+VqysrdZZkjvK64ge6lLygZaP7LgEPQ47tdRW9ergkkYNyzfhD/Hn0vRFWQvAjbWFgUFitFCf2lS1XZqXc03NjNA3mB2hkJgjkIiD+J+Nu4TDXGf0lpvDqujL6Ou9QK/vYLV3XqhMqxzWJ1zMtKpy0zhlcn99Yz74a6UEe9hoYBfQMIfYY3ELl5/HOVCs7SrtNElGY3qoggFHBHwty4gnVS2WGKyKD9ZQlffaQMCnT34gB+2/E42CrT4dz5mdmon7G62L6S9KD8+4wjmJXTOR2tx8olTvuQgHXrYDC+lqSGd5dEfm1OSgTWwDYzFH6AjT+mwpfV+kugCuhgfIbyQR4pwGuAHic4nS3txrc7JquIh4awQtfCAzEIyjMPI0bbJ2cLFEVTMvY166GsdVA0h3pUR2MluAxpZdT8FPMiucz2mq7aaqy2UtMk0HyxE2ASswa4bekw3B10Tmez9jGryOQRdgpYeUiu22HKBBWtyp8p8G0jwL0FhbGKq1EesgaWwyflWGJq9AXOVrzRrJUdthoqXjmhOBeiEgE02/5FyaSlsqBNBGO2FodkSYd5ffJ0oOxI1Cf3rdliC1NZIKNscXAjbZ3U/zWHdbgoMKULtUi41zZ/t6uBs1MEazObUjsg85KIm0dJuJ1F+uq3JneWVfiP3pE1YTUBggu20jvKMpt63t4k31EsOkqPDXu8z+E9GbhLuhbWR5UBCXinxNYwehfj1IdvKnSlM5zK4YKUmGuy2OBM1B8ZlnQxrbx3QatNYqUyDv84ozGPLb64nTZPZYotAY+BdzhtsXW+k1nAsttGgm8Gf3BXsmS2mRUY3rWs7+qx2hjp0IXvZFOZ/wMVmArWixCf6TwQjYA1mr/WeIfx1doKo8tsFbma0Nt2MR2MYow0GZ+A+Odh5cQ3F1wWwlVa0xgAUmdq7rii3DWz//BcSZ8P/ETsOMdyrl88Z/Ddj1Ulo+1E48uyqRDhndXTk+CibBSE6VmOSjYLSHsPbOD82/unVwLTH5EZo2IVYojhTCz+AtRPhdxELZtpSy6M9bNOKElDAfPSIy8Ufcg/5beBoWmYtRVdT3SZOVwi3sCIsME2ojX5Qb7UJ2IhlwVZBVJaACjMgzAnNGHzwqWQiegn4HdJW6KDsf4hfn3IWFDcTod/+bwWkfetPYqtaEbTl7gGe6Y54RXjuSeF2/3sQLTMNZkuzsF6ijMJeN6yXJDJ1LBPxZ+H5ND+6GbXENVDb/XUvlvqz2YbnZrgvQDjfNTYQ6XQMt4Dj0QGbtvw0wzLWFuiFW3DfzGahfJ/D5tWgjr1XdjZ8jyd3dEginReXATaMZm9thfnwRLW3MzbcdbCPw3luupnzXBeKQp9wF3E01PbdsF6Lc7CwNBlixOG53UgnOlQBJ6HFVYQr0mZ5rsbiIlDBbs4yukKUnQzwgMZCfIgxOJCj+jqQGbW5qoOWtlLuBJpKHtb8DrswxhCaWbRvkyZfXKBmTjOyji7TauXgf62L5zuKk79B5qqI53ms6KYi9uLmeW0kUSAd6csaP0DZtHN0FvBwzaKSTiWbJU4+SlJ3RPHRh3xuQqdueSliirwVC4MHwAXauS42/nsCPHcA3OHWcKlbT4uyL7Sof/8FMNIm/kgWpx/8HhRlx06G3EhMLpctteaJ8sPlEh2MaVWco6zo88OpDxIT9axP/eCzSF/4TR5F5iQRAf8nBXTbzRRhFX5MAHWrqhanKvydXLKjhYjLbiaVHcAUbpfvdGpKhJuJCBgRMCJgJQlI+5joE9NZwvxRlFBBOiJZigTepm5Db6RVEJtwnJ1+5rqjHoGFQXInwIwWhLnkmovyL57ux8TM9YdF17G9R618Wj9RX9dQ7mYv5FGxtv9oAtZ8E0CbHYSJOyeV5uJ0nlTsQc5BnEa47gG1Ph9bMZuzvQHq0MU4tyq/2uinzos+D0VC++TUHrizoQlNxTowzXvpLHP6EC6ZkdbH9QBc03oxfTKOzugiizgy+eOfB6bPzi02aVdeZnW3GfzIJkZ9ajUN9VfN7vpidelbzIujEH+GzTyZPllDB9pNC6Yf3IQX6UKSRXA2hHwbOUO5RR+yqIlcI386yJO+8ZkDduJPNu/5Q7AdNVkEDYEg3K3ChJysLencQfWN43GifM/mO6LMFuwB5HQhit3kWrhpxcqpefBjbFPySCztp2r9mQpXJwEoy+HVbH04C+vIa9kWdZML2A8qj6lMfaeGU8LqbTGKU7Gh+Sw8xubadG/ZEFaeG0mJVtycxlCODGrdfK+dhNoiXHz11G0RX6Od3aa7NdhCPt3DEPeo2yJ200j6CudvPrRFXxnvoctKCOe0kzrohg6JUkvOrMx5MfWBqafyxJ22kN8ldOvcckfWwvMrU8AJovxr4yZHX9RYU5kq/44A4YeE/Sc8KiQHpwrnr7fsqmwBBVSjKjZhBX42EjdFfAuEyLXBNi/9mh8Ctg8QfjYU2Uor4scxgFezCSfl8wd0N2534ax0K6BJmymG1kF92yAfqxfl+h6DUhIbqIg3sjG4lU/CUYnc7/BuxyKegXkxdSsZFTAv1t99SjEL3KWZjCyczrUcq5065pfLwrtiIhx1RMCIgBEBIwL+BgX8jwADAGX/oB4xE6GnAAAAAElFTkSuQmCC");
				background-repeat: no-repeat;
				width: 40px;
				height: 30px;
				display: block;
				margin: 0 10px 0 10px;
			}
		
			.sidebar_2_1_0_icon.icon-1 {
				background-position-y: -34px;
			}
		
			.sidebar_2_1_0_icon.icon-2 {
				background-position-y: -65px;
			}
		
			.sidebar_2_1_0_icon.icon-3 {
				background-position-y: -99px;
			}
		
			.sidebar_2_1_0_icon.icon-4 {
				background-position-y: -132px;
			}
		
			.sidebar_2_1_0_icon.icon-5 {
				background-position-y: -164px;
			}
		
			.sidebar_2_1_0_icon.icon-6 {
				background-position-y: -197px;
			}
		
			.sidebar_2_1_0 .modal .sidebar_img {
				text-align: center;
				margin: 0 auto;
				display: block;
				max-width: 100%;
				height: auto;
			}
		
			@media (max-width: 1024px) {
				.sidebar_2_1_0_tt p {
					font-size: 12px;
				}
			}
		
			@media (max-width: 812px) {
				.sidebar_2_1_0 {
					display: none;
				}
			}
			/*# sourceMappingURL=sidebar_2_1_0.css.map */
		</style>
		';
		
		add_action('wp_footer', 'sidebar_2_1_0');
        function sidebar_2_1_0(){ 
            echo '
			<script>
				$(".sidebar_2_1_0_item-2 .owl-carousel").owlCarousel({
					loop: false,
					margin: 20,
					items: 1,
					responsive: {
						0: {
							items: 1
						},
						414: {
							items: 1
						},
						768: {
							items: 1
						},
						1024: {
							items: 1
						}
					}
				});
			
				$(".modal-btn").click(function(e) {
					e.preventDefault();
					dataModal = $(this).attr("data-modal");
					$("#" + dataModal).css({
						"display": "block"
					});
				});
			
				$(".modal-closePic, .modal-bg").click(function() {
					$(".modal").css({
						"display": "none"
					});
				});
			</script>
            ';           
        };
    }
?>      


<section class="sidebar_2_1_0">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-3 col-sm-3 col-xs-6 sidebar_2_1_0">
				<?php
					foreach( $field as $key2 => $value): 
						foreach( $value as $key3 => $list):
							 
							if( $list['acf_fc_layout'] == 'sidebar_title' ):
								$list = explode("\n",  $list["title"]);
									echo'
									<a href="'.$list[0].'" class="sidebar_2_1_0_tt">
										<span class="sidebar_2_1_0_icon icon-'. $key3.'"></span>
										<p>'.$list[1].'</p>
									</a>
								';
								
								
								// End Tieu De
								
							elseif( $list['acf_fc_layout'] == 'sidebar_sv' ):
								echo '
									<div class="sidebar_2_1_0_item-4">
										'.$list['content'].'
									</div>
								';
								// End List Dich Vu

							elseif( $list['acf_fc_layout'] == 'sidebar_new' ):
								foreach($list['content'] as $key4 => $post):
									setup_postdata($post);
									$link = get_permalink();
									$title = get_the_title();
									$img = get_the_post_thumbnail_url();
									echo'
									<div class="sidebar_2_1_0_item-7">
										<div class="siderbar_news">
											<div class="siderbar_news-item">
												<div class="img">
													<img src="/rs/?w=60&h=60&src='.$img.' ?>" alt="">
												</div>
												<div class="tt">
													<a href="'.$link.'" class="tt-1">'.$title.'</a><br>
													<a href="'.$link.'" class="more">Xem thêm >></a>
												</div>
											</div>
										</div>
									</div>
									';
								endforeach;
								wp_reset_postdata(); 
							
							// End Tin tức

							elseif( $list['acf_fc_layout'] == 'sidebar_img' ):
								echo '
									<div class="sidebar_2_1_0_item-2">
										<div class="owl-carousel owl-theme">
								';
								$rows = $list["sidebar_sub"];
								foreach($rows as $key => $row):
									$data1 = explode("\n",  $row["sidebar_info"]);
									$data2 = $row['sidebar_pic'];
									echo'
										<div class="item modal-btn" data-modal="modal-pic'.$key.'">
											<img src="/rs/?w=270&h=270&src='.$data2.'" alt="">
											<span>'.$data1[0].'</span>
											<p>'.$data1[1].'</p>
										</div>
									';
								endforeach;
									echo'
									</div>
									</div>
									';
								foreach($rows as $key => $row):
									$data2 = $row['sidebar_pic'];
									echo'
									<div class="modal" id="modal-pic'.$key.'" style="display: none;">
										<div class="modal-closePic">×</div>
										<div class="modal-bg"></div>
										<div class="modal-box modal-box-img animate-zoom">
											<div class="modal-pic">
												<img class="sidebar_img" src="/rs/?w=650&h=450&src='.$data2.'" alt="">
											</div>
										</div>
									</div>
									';
								endforeach;
								

								// End thư viện ảnh
							elseif( $list['acf_fc_layout'] == 'sidebar_banner' ):
									$list = explode("\n",  $list["sb_banner"]);
									echo '
										<div class="sidebar_2_1_0_item-6">
											<div class="uu-dai">
												<a href="'.$list[1].'">
													<img src="/rs/?w=270&h=170&src='.$list[0].'" alt="">
													<span>'.$list[2].'</span>
												</a>
											</div>
										</div>
									';
										
							endif;

							// End List ưu đãi

						endforeach;
					endforeach;
				?>

				
			</div>
		</div>
	</div>
</section>



