<?php 
    $path = '/wp-content/themes/ParisBrand2019';
    $path = $path.'/Module_v2/Landing/person_ld_4_0_0';
	$content .= '
    <section id="" class="person_ld_4_0_0">
        <div class="container">
            <div class="person_ld_4_0_0_title">
                kết quả trồng răng implant 4s<br> tại nha khoa paris
                <p>giải pháp tốt nhất - ăn nhai trọn đời</p>
            </div>
            <div class="person_ld_4_0_0_box1 owl-carousel owl-theme">
                <div class="">
                    <div class="person_ld_4_0_0__item person_ld_4_0_0__item1">
                        <div class="person_ld_4_0_0__pic">
                            <img class="lazy" data-src="images/person_ld_4_0_0-pic1.jpg">
                        </div>
                        <div class="person_ld_4_0_0__ct">
                            <span>anh hoàng </span> Mất 2 răng cửa - Trồng Implant 2 răng
                        </div>
                    </div>
                    <div class="person_ld_4_0_0__item">
                        <div class="person_ld_4_0_0__pic">
                            <img class="lazy" data-src="images/person_ld_4_0_0-pic4.jpg">
                        </div>
                        <div class="person_ld_4_0_0__ct">
                            <span>lê chí công </span> Mất răng cửa - Trồng implant Hàn Quốc
                        </div>
                    </div>
                </div>
                <div class="">
                    <div class="person_ld_4_0_0__item person_ld_4_0_0__item1">
                        <div class="person_ld_4_0_0__pic">
                            <img class="lazy" data-src="images/person_ld_4_0_0-pic2.jpg">
                        </div>
                        <div class="person_ld_4_0_0__ct">
                            <span>cô nhiệm </span> Mất răng toàn hàm - Trồng răng implant all on 6
                        </div>
                    </div>
                    <div class="person_ld_4_0_0__item">
                        <div class="person_ld_4_0_0__pic">
                            <img class="lazy" data-src="images/person_ld_4_0_0-pic5.jpg">
                        </div>
                        <div class="person_ld_4_0_0__ct">
                            <span>Nguyễn thế vinh</span> Mất răng toàn hàm - Trồng Implant all on 4 cả 2 hàm
                        </div>
                    </div>
                </div>
                <div class="">
                    <div class="person_ld_4_0_0__item person_ld_4_0_0__item1">
                        <div class="person_ld_4_0_0__pic">
                            <img class="lazy" data-src="images/person_ld_4_0_0-pic3.jpg">
                        </div>
                        <div class="person_ld_4_0_0__ct">
                            <span>đoàn thị sánh </span> Mất răng toàn hàm - Trồng implant all on 6 2 hàm
                        </div>
                    </div>
                    <div class="person_ld_4_0_0__item">
                        <div class="person_ld_4_0_0__pic">
                            <img class="lazy" data-src="images/person_ld_4_0_0-pic6.jpg">
                        </div>
                        <div class="person_ld_4_0_0__ct">
                            <span>nguyễn thị lệ </span> Mất một răng cửa bên - Trồng implant Thụy Sỹ
                        </div>
                    </div>
                </div>
            </div>
            <div class="person_ld_4_0_0_box2 owl-carousel owl-theme">
                <div class="person_ld_4_0_0__item">
                    <div class="person_ld_4_0_0__pic">
                        <img class="lazy" data-src="images/person_ld_4_0_0-pic1.jpg">
                    </div>
                    <div class="person_ld_4_0_0__ct">
                        <span>anh hoàng </span> Mất 2 răng cửa - Trồng Implant 2 răng
                    </div>
                </div>
                <div class="person_ld_4_0_0__item">
                    <div class="person_ld_4_0_0__pic">
                        <img class="lazy" data-src="images/person_ld_4_0_0-pic4.jpg">
                    </div>
                    <div class="person_ld_4_0_0__ct">
                        <span>lê chí công </span> Mất răng cửa - Trồng implant Hàn Quốc
                    </div>
                </div>
                <div class="person_ld_4_0_0__item person_ld_4_0_0__item1">
                    <div class="person_ld_4_0_0__pic">
                        <img class="lazy" data-src="images/person_ld_4_0_0-pic2.jpg">
                    </div>
                    <div class="person_ld_4_0_0__ct">
                        <span>cô nhiệm </span> Mất răng toàn hàm - Trồng răng implant all on 6
                    </div>
                </div>
                <div class="person_ld_4_0_0__item">
                    <div class="person_ld_4_0_0__pic">
                        <img class="lazy" data-src="images/person_ld_4_0_0-pic5.jpg">
                    </div>
                    <div class="person_ld_4_0_0__ct">
                        <span>Nguyễn thế vinh</span> Mất răng toàn hàm - Trồng Implant all on 4 cả 2 hàm
                    </div>
                </div>
                <div class="person_ld_4_0_0__item person_ld_4_0_0__item1">
                    <div class="person_ld_4_0_0__pic">
                        <img class="lazy" data-src="images/person_ld_4_0_0-pic3.jpg">
                    </div>
                    <div class="person_ld_4_0_0__ct">
                        <span>đoàn thị sánh </span> Mất răng toàn hàm - Trồng implant all on 6 2 hàm
                    </div>
                </div>
                <div class="person_ld_4_0_0__item">
                    <div class="person_ld_4_0_0__pic">
                        <img class="lazy" data-src="images/person_ld_4_0_0-pic6.jpg">
                    </div>
                    <div class="person_ld_4_0_0__ct">
                        <span>nguyễn thị lệ </span> Mất một răng cửa bên - Trồng implant Thụy Sỹ
                    </div>
                </div>
            </div>
            <div class="person_ld_4_0_0_regist">
                <a href="">>> Đăng ký tư vấn <<</a>
            </div>
        </div>
    </section>
    ';
    $html1 = str_replace('src="','src="'.$path.'/',$content);
    echo $html = str_replace('srcset="','srcset="'.$path.'/',$html1);
?>