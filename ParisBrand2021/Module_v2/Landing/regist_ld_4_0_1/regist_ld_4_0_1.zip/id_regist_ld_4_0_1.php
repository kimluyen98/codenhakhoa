<?php
    /*Regist LD 4.0.1*/
    'id_regist_ld_4_0_1' => array(
        'key' => 'id_regist_ld_4_0_1',
        'name' => 'regist_ld_4_0_1',
        'label' => 'Regist LD 4.0.1',
        'display' => 'block',
        'sub_fields' => array(
            /*Bắt đầu field*/
            array(
                'key' => 'id_regist_ld_4_0_1_sub1',
                'label' => 'Code HTML',
                'name' => 'info',
                'type' => 'textarea',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => $html_id_regist_ld_4_0_1,
                'placeholder' => '',
                'maxlength' => '',
                'rows' => 15,
                'new_lines' => '',
            ),

        
            /*End field*/
        ),
        'min' => '',
        'max' => '',
    ),
    /*END Regist LD 4.0.1*/
?>