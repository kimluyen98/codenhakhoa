<?php
    /*Doctor LD 3.1.1*/
    'id_doctor_ld_3_1_1' => array(
        'key' => 'id_doctor_ld_3_1_1',
        'name' => 'doctor_ld_3_1_1',
        'label' => 'Doctor LD 3.1.1',
        'display' => 'block',
        'sub_fields' => array(
            /*Bắt đầu field*/
            array(
                'key' => 'id_doctor_ld_3_1_1_sub1',
                'label' => 'Code HTML',
                'name' => 'info',
                'type' => 'textarea',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => $html_id_doctor_ld_3_1_1,
                'placeholder' => '',
                'maxlength' => '',
                'rows' => 15,
                'new_lines' => '',
            ),

        
            /*End field*/
        ),
        'min' => '',
        'max' => '',
    ),
    /*END Doctor LD 3.1.1*/
?>