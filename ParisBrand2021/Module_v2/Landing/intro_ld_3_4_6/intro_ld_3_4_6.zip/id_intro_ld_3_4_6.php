<?php
    /*Intro LD 3.4.6*/
    'id_intro_ld_3_4_6' => array(
        'key' => 'id_intro_ld_3_4_6',
        'name' => 'intro_ld_3_4_6',
        'label' => 'Intro LD 3.4.6',
        'display' => 'block',
        'sub_fields' => array(
            /*Bắt đầu field*/
            array(
                'key' => 'id_intro_ld_3_4_6_sub1',
                'label' => 'Code HTML',
                'name' => 'info',
                'type' => 'textarea',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => $html_id_intro_ld_3_4_6,
                'placeholder' => '',
                'maxlength' => '',
                'rows' => 15,
                'new_lines' => '',
            ),

        
            /*End field*/
        ),
        'min' => '',
        'max' => '',
    ),
    /*END Intro LD 3.4.6*/
?>