    $('.service_3_0_0 .owl-carousel').owlCarousel({
        loop: false,
        margin: 10,
        items: 1,
        responsive: {
            0: {
                items: 2
            },
            414: {
                items: 2
            },
            768: {
                items: 3
            },
            1024: {
                items: 3
            },
            1280: {
                items: 3
            },
        }
    });