<?php
    /*Intro LD 3.7.0*/
    'id_intro_ld_3_7_0' => array(
        'key' => 'id_intro_ld_3_7_0',
        'name' => 'intro_ld_3_7_0',
        'label' => 'Intro LD 3.7.0',
        'display' => 'block',
        'sub_fields' => array(
            /*Bắt đầu field*/
            array(
                'key' => 'id_intro_ld_3_7_0_sub1',
                'label' => 'Code HTML',
                'name' => 'info',
                'type' => 'textarea',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => $html_id_intro_ld_3_7_0,
                'placeholder' => '',
                'maxlength' => '',
                'rows' => 15,
                'new_lines' => '',
            ),

        
            /*End field*/
        ),
        'min' => '',
        'max' => '',
    ),
    /*END Intro LD 3.7.0*/
?>