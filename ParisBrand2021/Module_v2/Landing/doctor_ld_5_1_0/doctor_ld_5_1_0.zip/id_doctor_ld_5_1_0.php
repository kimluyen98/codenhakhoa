<?php
    /*Doctor LD 5.1.0*/
    'id_doctor_ld_5_1_0' => array(
        'key' => 'id_doctor_ld_5_1_0',
        'name' => 'doctor_ld_5_1_0',
        'label' => 'Doctor LD 5.1.0',
        'display' => 'block',
        'sub_fields' => array(
            /*Bắt đầu field*/
            array(
                'key' => 'id_doctor_ld_5_1_0_sub1',
                'label' => 'Code HTML',
                'name' => 'info',
                'type' => 'textarea',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => $html_id_doctor_ld_5_1_0,
                'placeholder' => '',
                'maxlength' => '',
                'rows' => 15,
                'new_lines' => '',
            ),

        
            /*End field*/
        ),
        'min' => '',
        'max' => '',
    ),
    /*END doctor LD 5.1.0*/
?>