<?php
    /*Intro LD 3.6.2*/
    'id_intro_ld_3_6_2' => array(
        'key' => 'id_intro_ld_3_6_2',
        'name' => 'intro_ld_3_6_2',
        'label' => 'Intro LD 3.6.2',
        'display' => 'block',
        'sub_fields' => array(
            /*Bắt đầu field*/
            array(
                'key' => 'id_intro_ld_3_6_2_sub1',
                'label' => 'Code HTML',
                'name' => 'info',
                'type' => 'textarea',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => $html_id_intro_ld_3_6_2,
                'placeholder' => '',
                'maxlength' => '',
                'rows' => 15,
                'new_lines' => '',
            ),

        
            /*End field*/
        ),
        'min' => '',
        'max' => '',
    ),
    /*END Intro LD 3.6.2*/
?>