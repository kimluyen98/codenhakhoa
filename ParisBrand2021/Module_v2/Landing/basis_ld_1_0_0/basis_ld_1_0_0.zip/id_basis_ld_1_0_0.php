<?php
    /*Basis LD 1.0.0*/
    'id_basis_ld_1_0_0' => array(
        'key' => 'id_basis_ld_1_0_0',
        'name' => 'basis_ld_1_0_0',
        'label' => 'Basis LD 1.0.0',
        'display' => 'block',
        'sub_fields' => array(
            /*Bắt đầu field*/
            array(
                'key' => 'id_basis_ld_1_0_0_sub1',
                'label' => 'Code HTML',
                'name' => 'info',
                'type' => 'textarea',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => $html_id_basis_ld_1_0_0,
                'placeholder' => '',
                'maxlength' => '',
                'rows' => 15,
                'new_lines' => '',
            ),

        
            /*End field*/
        ),
        'min' => '',
        'max' => '',
    ),
    /*END Basis LD 1.0.0*/
?>