<?php
    /*Step LD 4.1.0*/
    'id_step_ld_4_1_0' => array(
        'key' => 'id_step_ld_4_1_0',
        'name' => 'step_ld_4_1_0',
        'label' => 'Step LD 4.1.0',
        'display' => 'block',
        'sub_fields' => array(
            /*Bắt đầu field*/
            array(
                'key' => 'id_step_ld_4_1_0_sub1',
                'label' => 'Code HTML',
                'name' => 'info',
                'type' => 'textarea',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => $html_id_step_ld_4_1_0,
                'placeholder' => '',
                'maxlength' => '',
                'rows' => 15,
                'new_lines' => '',
            ),

        
            /*End field*/
        ),
        'min' => '',
        'max' => '',
    ),
    /*END Step LD 4.1.0*/
?>