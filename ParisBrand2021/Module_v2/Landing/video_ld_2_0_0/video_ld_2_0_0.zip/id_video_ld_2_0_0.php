<?php
    /*Video LD 2.0.0*/
    'id_video_ld_2_0_0' => array(
        'key' => 'id_video_ld_2_0_0',
        'name' => 'video_ld_2_0_0',
        'label' => 'Video LD 2.0.0',
        'display' => 'block',
        'sub_fields' => array(
            /*Bắt đầu field*/
            array(
                'key' => 'id_video_ld_2_0_0_sub1',
                'label' => 'Code HTML',
                'name' => 'info',
                'type' => 'textarea',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => $html_id_video_ld_2_0_0,
                'placeholder' => '',
                'maxlength' => '',
                'rows' => 15,
                'new_lines' => '',
            ),

        
            /*End field*/
        ),
        'min' => '',
        'max' => '',
    ),
    /*END Video LD 2.0.0*/
?>