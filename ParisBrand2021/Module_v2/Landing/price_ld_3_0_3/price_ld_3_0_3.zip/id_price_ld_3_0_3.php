<?php
    /*Price LD 3.0.3*/
    'id_price_ld_3_0_3' => array(
        'key' => 'id_price_ld_3_0_3',
        'name' => 'price_ld_3_0_3',
        'label' => 'Price LD 3.0.3',
        'display' => 'block',
        'sub_fields' => array(
            /*Bắt đầu field*/
            array(
                'key' => 'id_price_ld_3_0_3_sub1',
                'label' => 'Code HTML',
                'name' => 'info',
                'type' => 'textarea',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => $html_id_price_ld_3_0_3,
                'placeholder' => '',
                'maxlength' => '',
                'rows' => 15,
                'new_lines' => '',
            ),

        
            /*End field*/
        ),
        'min' => '',
        'max' => '',
    ),
    /*END Price LD 3.0.3*/
?>