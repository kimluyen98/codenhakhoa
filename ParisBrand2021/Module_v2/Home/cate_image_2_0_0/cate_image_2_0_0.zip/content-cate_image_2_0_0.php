<?php
	$path = get_template_directory_uri();
	$path = $path.'/Module/Home/cate_image_2_0_0';

	if($check == 0){
		echo '
		<style>
			a {
				text-decoration: none;
			}
			
			.cate_image_2_0_0_doctor__Title h2,
			.cate_image_2_0_0_KH__title {
				font-family: -apple-system, system-ui, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
			}
			
			@media (max-width: 414px) {
				.pc {
					display: none;
				}
			}
			
			.mb {
				display: none;
			}
			
			@media (max-width: 414px) {
				.mb {
					display: block;
				}
			}
			
			.cate_image_2_0_0 {
				padding: 30px 0;
			}
			
			.cate_image_2_0_0 .disabled {
				background: none !important;
				cursor: unset !important;
			}
			
			.cate_image_2_0_0_doctor {
				background: #fff;
				box-shadow: 0px 0px 10px #ccc;
				padding: 20px 0;
				min-height: 650px;
				position: relative;
			}
			
			.cate_image_2_0_0_doctor__Title h2 {
				font-size: 26px;
				color: #0055A4;
				text-transform: uppercase;
				padding-left: 30px;
				padding-top: 0px;
				font-weight: 600;
			}
			
			.cate_image_2_0_0_doctor__Title h2 br {
				display: none;
			}
			
			.cate_image_2_0_0_doctor__ct {
				padding: 20px 30px 20px 30px;
				color: #000;
				border-radius: 8px;
				text-align: left;
			}
			
			.cate_image_2_0_0_doctor__ct ul {
				padding: 0;
				list-style: none;
			}
			
			.cate_image_2_0_0_doctor__ct ul li {
				padding-bottom: 5px;
			}
			
			.cate_image_2_0_0__tab {
				margin-top: -100px;
			}
			
			.cate_image_2_0_0__tab .owl-carousel {
				width: 90%;
				margin: 0 auto;
			}
			
			.cate_image_2_0_0__tab .owl-carousel .owl-nav {
				display: block;
			}
			
			.cate_image_2_0_0__tab .owl-carousel img {
				width: auto;
				margin: 0 auto;
				border: 3px solid #E6E6E6;
				border-radius: 100%;
			}
			
			.cate_image_2_0_0__tab .owl-prev,
			.cate_image_2_0_0__tab .owl-next {
				display: block;
				position: absolute;
				top: 0;
			}
			
			.cate_image_2_0_0__tab .owl-prev span,
			.cate_image_2_0_0__tab .owl-next span {
				font-size: 70px;
				color: #BABABA;
			}
			
			.cate_image_2_0_0__tab .owl-prev {
				left: -55px;
			}
			
			.cate_image_2_0_0__tab .owl-next {
				right: -55px;
			}
			
			.cate_image_2_0_0__tab .owl-carousel .owl-nav button.owl-prev,
			.cate_image_2_0_0__tab .owl-carousel .owl-nav button.owl-next {
				background: none;
			}
			
			.cate_image_2_0_0__tab__item {
				background: #fff;
				padding: 10px;
				text-align: center;
				display: block;
				box-shadow: 0px 0px 10px #ccc;
				border: 0.2px solid #eee;
			}
			
			.cate_image_2_0_0__tab__item .info {
				padding: 15px 0 0;
			}
			
			.cate_image_2_0_0__tab__item .info b {
				text-transform: uppercase;
			}
			
			.cate_image_2_0_0__tab__item.active {
				background: #EAF9FF;
			}
			
			.cate_image_2_0_0__tab__item.active .pic img {
				border: 3px solid #6DCFF6;
			}
			
			.cate_image_2_0_0__tab__item:hover {
				background: #EAF9FF;
			}
			
			.cate_image_2_0_0__tab__item:hover img {
				border: 3px solid #6DCFF6;
			}
			
			.cate_image_2_0_0_KH__title {
				font-size: 26px;
				color: #0055A4;
				text-transform: uppercase;
				padding: 30px 0;
				font-weight: 600;
			}
			
			.cate_image_2_0_0_KH .pic img {
				width: 100%;
			}
			
			.cate_image_2_0_0_KH .sub {
				text-align: center;
				padding: 10px 0;
			}
			
			@media (max-width: 1024px) {
				.cate_image_2_0_0_doctor {
					min-height: 530px;
				}
				.cate_image_2_0_0_doctor__Title h2 {
					font-size: 20px;
				}
				.cate_image_2_0_0_doctor__ct {
					padding: 10px 30px 20px 30px;
				}
				.cate_image_2_0_0_doctor__ct ul li {
					padding-bottom: 3px;
					font-size: 13px;
				}
				.cate_image_2_0_0__tab .owl-carousel img {
					width: 100%;
				}
				.cate_image_2_0_0__tab__item .info {
					font-size: 12px;
				}
				.cate_image_2_0_0_KH__title {
					padding: 20px 0;
				}
				.cate_image_2_0_0_KH .sub {
					font-size: 12px;
				}
				.cate_image_2_0_0_KH .row .col-md-3 {
					flex: 0 0 25%;
					max-width: 25%;
				}
			}
			
			@media (max-width: 812px) {
				.cate_image_2_0_0_doctor__Title h2 {
					margin-top: 0;
				}
				.cate_image_2_0_0_doctor__Title h2 br {
					display: block;
				}
				.cate_image_2_0_0_doctor__ct {
					padding-top: 0;
				}
				.cate_image_2_0_0_doctor__ct ul {
					margin-top: 4px;
				}
				.cate_image_2_0_0_doctor__ct ul li {
					font-size: 12px;
				}
				.cate_image_2_0_0__tab__item {
					padding: 5px;
				}
				.cate_image_2_0_0__tab .owl-prev {
					left: -45px;
				}
				.cate_image_2_0_0__tab .owl-next {
					right: -45px;
				}
				.cate_image_2_0_0_KH .sub {
					font-size: 13px;
				}
			}
			
			@media (max-width: 414px) {
				.cate_image_2_0_0_doctor__Title h2 {
					padding-left: 0;
					text-align: center;
				}
				.cate_image_2_0_0__tab {
					margin-top: 0;
				}
				.cate_image_2_0_0__tab .owl-prev,
				.cate_image_2_0_0__tab .owl-next {
					top: 30px;
				}
				.cate_image_2_0_0__tab .owl-prev span,
				.cate_image_2_0_0__tab .owl-next span {
					font-size: 50px;
				}
				.cate_image_2_0_0__tab .owl-prev {
					left: -35px;
				}
				.cate_image_2_0_0__tab .owl-next {
					right: -35px;
				}
				.cate_image_2_0_0__tab .info p {
					margin-bottom: 0;
				}
				.cate_image_2_0_0_KH__title {
					text-align: center;
					font-size: 20px;
				}
				.cate_image_2_0_0_KH .row {
					margin-right: -8px;
					margin-left: -8px;
				}
				.cate_image_2_0_0_KH .row .col-md-3 {
					flex: 0 0 50%;
					max-width: 50%;
					padding-left: 8px;
					padding-right: 8px;
				}
			}
			/*# sourceMappingURL=cate_image_2_0_0.css.map */
		</style>

        ';
		add_action('wp_footer', 'cate_image_2_0_0');
		function cate_image_2_0_0(){ 
			echo '
				<script>
					$(".cate_image_2_0_0_doctor__big .owl-carousel").owlCarousel({loop:!1,margin:20,items:1,nav:!1,dots:!1,responsive:{0:{items:1},414:{items:1,nav:!1},768:{items:1}}});
					$(".cate_image_2_0_0__tab .owl-carousel").owlCarousel({loop:!1,margin:20,items:1,nav:!0,dots:!1,responsive:{0:{items:2},414:{items:3,margin:10},768:{items:5},1024:{items:6}}});
					$(".cate_image_2_0_0_KH .owl-carousel").owlCarousel({items:3,loop:!1,pullDrag:!1,rewind:!0,autoplay:!1,margin:10,nav:!1,dots:!1,responsive:{320:{items:1},360:{items:1}}});
					var $tabs2 = $(".cate_image_2_0_0_tabs2 .tab");
					$tabs2.click(function(event) {
						var selectedClass = "active";
						$(".cate_image_2_0_0_tabs2 .tab,.cate_image_2_0_0_tabs2 .tab img").removeClass(selectedClass);
						$(event.target).addClass(selectedClass);
					});
				</script>
            ';           
        };
			
	}
	
?>
<section class="cate_image_2_0_0">
	<div class="container">
		<div class="mb cate_image_2_0_0_doctor__Title">
			<h2>
				<?php
					$value = $field['title'];
					$data = explode("\n",  $value);
						echo $data[0]; 
				?>
			</h2>
		</div>
		<div class="cate_image_2_0_0_doctor pc">
			<div class="cate_image_2_0_0_doctor__big">
				<div class="owl-carousel owl-theme">
					<?php
						$i = 1;
						foreach($field['info'] as $key => $value):
							$data = explode("\n",  $value["info_doctor_content"]);
							$value3 = $field['title'];
							$data3 = explode("\n",  $value3);
							echo '
							<div class="cate_image_2_0_0_doctor__item" data-hash="d'.$i.'">
							<div class="row">
								<div class="col-md-6">
									<div class="cate_image_2_0_0_doctor__Title">
										<h2>'.$data3[0].'</h2>
									</div>
									<div class="cate_image_2_0_0_doctor__ct">
										<div class="cate_image_2_0_0_doctor__name">'.$data[0].''.$data[1].'</div>
											'.$value['sub'].'
									</div>
								</div>
								<div class="col-md-6">
									<picture>
										<source media="(min-width:600px)" srcset="'.$data[2].'">
										<img src="'.$data[3].'" alt="">
									</picture>
								</div>
							</div>
						</div>
							';
							$i++;
						endforeach;
					?>  
				</div>
			</div>
		</div>
		<div class="cate_image_2_0_0__tab">
			<div class="owl-carousel owl-theme cate_image_2_0_0_tabs2">
				
				<?php
					$i = 1;
					foreach($field['info'] as $key => $value):
						$data = explode("\n",  $value["info_doctor_content"]);
						if($key == 0 ):
							$current = 'active';
						else: 
							$current = '';
						endif;
						echo '
							<a class="cate_image_2_0_0__tab__item tab '.$current.'" href="#d'.$i.'">
								<div class="pic">
									<img class="img-lazy" data-src="'.$data[4].'" alt="">
								</div>
								<div class="info">
									<p>'.$data[0].'<br> <b>'.$data[1].'</b></p>
								</div>
							</a>
						';
						$i++;
					endforeach;
				?>  
			</div>
		</div>
		<div class="cate_image_2_0_0_KH">
			<div class="cate_image_2_0_0_KH__title">
			<?php
				$value = $field['title'];
				$data = explode("\n",  $value);
					echo $data[1]; 
			?>
			</div>
			<div class="owl-carousel owl-theme">
			<?php
					$i = 1;
					foreach($field['info'] as $value_0):
						echo'
							<div class="cate_image_2_0_0_KH__box" data-hash="d'.$i.'">';
							echo'<div class="mb">';
								foreach($value_0 as $value_1):
									foreach($value_1 as $key => $value):
									$data2 = explode("\n",  $value["info_KH_content"]);
									if ($key == 0):
									echo'
										<div class="pic">
											<img src="'.$data2[0].'" alt="">
										</div>
										<div class="sub">
											<b>'.$data2[1].'</b>
											<p>'.$data2[2].'</p>
										</div>
									';
									endif;
									endforeach;
								endforeach;
							echo' </div> ';
							echo' <div class="row"> ';
								foreach($value_0 as $value_1):
									foreach($value_1 as $key => $value):
									$data2 = explode("\n",  $value["info_KH_content"]);
									if ($key > 0):
									echo'
										<div class="col-md-3">
											<div class="pic">
												<img src="'.$data2[0].'" alt="">
											</div>
											<div class="sub">
												<b>'.$data2[1].'</b>
												<p>'.$data2[2].'</p>
											</div>
										</div>
									';
									endif;
									endforeach;
								endforeach;
							echo' </div> ';
						echo'
						</div>
						';
						$i++;
					
					endforeach;
				?>
			
			</div>
		</div>
	</div>
</section>




