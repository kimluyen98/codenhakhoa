<?php
	$path = get_template_directory_uri();
	$path = $path.'/Module/Home/commit_1_0_0';
	foreach($field['contact_info'] as $value_4):
		foreach($value_4 as $value_5):
			foreach($value_5 as $value7):
			$data3 = explode("\n",  $value7["content"]);
			$address = $data3[0];
			endforeach;
		endforeach;
	endforeach;

	if($check == 0){
		$css_inline .= "
		<style>
			a {
				text-decoration: none;
			}
			
			@font-face {
				font-family: 'GMVDino';
				src: url('.$path.'/font/GMV_DIN_Pro.ttf);
			}
			
			.commit_1_0_0,
			.commit_1_0_0__title h2,
			.commit_1_0_0__box3 h3 {
				font-family: GMVDino;
			}
			
			.commit_1_0_0 .container:before {
				content: '';
				display: block;
				background: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABEEAAAAoCAYAAAAR1eRVAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6RDlBMjUyRkQ1MTQ1MTFFQTk1NDRCNjhCNkYyMzdBRkQiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6RDlBMjUyRkU1MTQ1MTFFQTk1NDRCNjhCNkYyMzdBRkQiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpEOUEyNTJGQjUxNDUxMUVBOTU0NEI2OEI2RjIzN0FGRCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpEOUEyNTJGQzUxNDUxMUVBOTU0NEI2OEI2RjIzN0FGRCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PvFSjfkAAAnCSURBVHja7N17jFRXHcDx3zx2Z/bBaxcQWag11QWMTWmEShNEba3WSKiERKpg4l8trYJ/VC0aY1FjlD/qH2hjQW2q1NLSRiqJMRYKhW6FBCgUymuB8NqBLY8Fdnd23nM95+7tMjt7Z+bOzoOZ5ftJftkzM+fee3IGdu789jxchmEIAABANoF5cws53K1itoovq5ilolVFi4oG6/WgvoSKdhV7VWxXsUdFcjgXa9nZxhsGAABseekCAABQIlNUfF/FEhVTs9TzqWhScbeKRdZz51X8Q8VzKjroSgAAUAxuugAAABRZs/QnL06pWCnZEyCZTLWOPWWdq5luBQAAhSIJAgAAiulbKo6peFJFbRHOV2udS59zMd0LAAAKQRIEAAAUg55i+ycVr6oYX4Lz63O+Yl2D6bwAAGBYSIIAAIBC1avYpGJZGa61zLpWPd0OAADyRRIEAAAUQo/K2KBifhmvOd+6JiNCAABAXkiCAACAQvxRxYJbcN0F1rUBAAAc4y8oAABguPRCpY/bveCZNEkaFz8qtTM+I8meHokeOijhXbskfua0GLHYkPruMWOkpnWa+OfMUT9bzefCbW0S3PRPMaLRTNfX194h/aNCAAAAciIJAgAAhkNvWWs7EsPd2ChjV/xQ/HO/MPCcf/Zsqf/awxJ+Z6eE/veuxE6dEiMYNF+re+BBqfvil8Q38x5xj2saOMb32bvF5fNJz/q/ixhGpnboNmxVcZm3BAAA5OIyMt9UAAAAmALz5qY/pXdpGbIQqk6AjF72pDQsyDxDxojHJX7mjMSOH5fo0cNmssQ/5/6M9btWPSOhbW9la97a1La07GzjDQMAALZIggAAgJzSkiB3qDipoia9Xv035svYp34kLq/zwaY6KeLyeNRdicv29diJdun65SqJnzuX6RR6fs2nVJgVSIIAAIBMvCsOhOgFAACQ1dODHz4hNgkQTa/p4SgBkkhIMhwSd0NjzvreOz8pvntmZkuC1Fht+ql+wL0NAADIhN1hAABAvvcOSzO96Jkw0dFJ4p0XpXvtWkd1XTU16rwTclVbyn0NAADIRf/pxaei3npcq6LBpqz/wtJoU9bHj7Ipe1SMtinrm5MxNmU9/nVsjrI2jrcMAIDyW71mi/lz8tlj8t1nl2esZ0QiOc+ld4cJ794tkffek+jRI+YOMlklk7Y7yqSZsv6pPyQufGI6bxYAAOV3LaV8XX/c5yjf0J/wNuVuFQmbco+KuE25V/qnxaaX9errUZtyn05cRKyoNqkJEZ0ocdmUdZLFbVPWSRmPTVkncbw2ZZ30qbEp6yRRrU1ZJ5V8NmUAAKraHe37s74eP39OfPfem7WO3jK3d8PLkrh0SXo3bpSmZ1Zlra8TK/GO8w7adkBIggAAqpz+bt5nU45aX+bTyzHry396OW4lC9LLCSu5kF5OWsmI9LJhJS/Sy+mJj6pRzVvkXqvCzq9T4c9R9luP08upI3bKOXoHAIABk86fyH7ntnev1D/0VXHV1WWs4xk3ThoWPCLdL/xVGhctynnNaPtxiR4+7KBt7bxBAIBUJR9VIDcHFKSW9eJUYZty2HqcXk5NdqDEvHRBWYVS/qFXS+KmmFOYyjl6BwBQAk0fZh+REdm7R0I73pb6h7+euZLLJa7a/sGTLl/uwZJ9mzdL4vLlgtsGABi2co8qKNbUCmAIvjAil2TaL6GrVdLuYk1hKufoHQCo/F+u3V3ZPzR6e6Xnby+K777Pi6epKWO9RFeXudaHnhqTTfjdNgm9vV3d5hoFtw0AKkQ5RxUUa2oFMGKQBMFIlfoLu1pG3VTiAsRORu8AuI3UhnOP1o0HAnL9d7+Vpl/9Wlx+v22d5LX+hEXy+vWM54mdaJfrv3/WyaKojtsGYEQp96iCYk2tAHALkQQBKkcs7UP6UpW0u9IWIHYyegdAiYV37zJHcdQ9+JUhr0XePyDhXbv7vxW8tlF8s2aJe/SYIfV6X3/d0TQYAMX5byvlG1VQrKkVAJA3kiAACpV6I1Ito24qbQFiJ6N3gIoQ9ddLXbDbUd3IoUO2SRCXt0aMeMofRD2eIXWMYFBip07m3TagQlTENpCS39QKALgtkAQBcDsKV+FNn9NpS5W2fThGmN7RTY6TIIlAh7nuh7jdg28+Jk8WT3OzyPjx4v34ZHE3NA499sYNSXR25t02jDiVuA2kk6kVAIAKRRIEAKqDIdW5NXilLUDsZPQOsuj62FSZcPGMo7qJq1clGQyKe9Tgrk1cuSJGJCL+OfdLrL3dNlGS1Md2d+fdNmRVCdtAOplmkZr4AACgqEiCAABKKZjyZaZaEjelWIBYK/XonbLonPppmXbgHUd19UgOnchITYLoNT661z0vya4ucztd8/Gf18noxx43t879SOzsmWG0rbVc3VCJ20A6mVoBAMBtjyQIAACDxdO+mF6pknaXZQHirolTJ6qf33TSIL1dbuJCQLwtLYM7uCPQP/LD6zV3fol/2Nm/BW5KEiR+9mzeHXCjedJ69eOClH7BRgAAUKVIggAAMDKkfkEv+qibp1c89FFRj0LRGYopTo6LfvCB+GbfN/DYM2GCOTKkprVVxvxguVxe9ph4W6YMng5jGBI9eiTfJnYsePE331ORXL1mC/8aAACALe+amXX0AgAAyCpws6inX7ykYqWT4yKHDg5abCV65Ii560vDwoVmQqRm2nQJbd8mo5YsFZe/fwmYeEeHxE+fzreJL1ltE+5tAABAJm66AAAA5Ok5ublgZlaxY8ckfu7cwOPQW1vNKTDBf70hV3/yY4mdPGm+Hjn4/kCdyP79kuzpyac9UatNAAAAWZEEAQAA+epQ8RcnFfW6IH1b3jTL8UBA+rb2T1XRI0LCu3dJovOi+Tj42kbrgKT0vfnffNvzgtUmAACArFgTBAAADMcvVCxW0ZyrYmjrFqmdPkNCO7ZL8pr9ciWRffsk+MYmcz2Q2JHD+bTjqoqf83YAAAAnXIZh0AsAACCrwLy5dk8/qmLDLW7aEhUvpz7RsrONNwwAANhiOgwAABiuV1SsvYXXXydpCRAAAIBsSIIAAIBCrFCx+RZcV19zOd0PAADyQRIEAAAUQu/M8m0V/ynjNf9tXTNK9wMAgHyQBAEAAIXqU/GIlGdqjL7GQuuaAAAAeSEJAgAAiiGmYpn0j9C4UoLz63N+x7pGjO4GAADDQRIEAAAUk14sdYaK56U401Wi1rn0OTfQvQAAoBAkQQAAQLHpURtPqLhLxWoVgWGcI2Ade5d1rit0KwAAKJSXLgAAACXSoWKlip+pmK3iARWfU9GqYoqKRqter1W3XcU+FdtU7FGRpAsBAEAx/V+AAQA33rAj/ZUP3AAAAABJRU5ErkJggg==') center 0 no-repeat;
				position: absolute;
				left: 0;
				top: 0px;
				width: 100%;
				height: 50px;
				background-size: 100%;
			}
			
			.commit_1_0_0__title h2 {
				font-size: 28px;
				color: #0055A4;
				text-transform: uppercase;
				font-weight: 600;
				padding: 40px 0 25px;
				text-align: left;
			}
			
			.commit_1_0_0__box1 .tabs {
				display: flex;
				justify-content: space-between;
			}
			
			.commit_1_0_0__box1 .tabs a {
				border: 1px solid #ccc;
				padding: 22.3px;
			}
			
			.commit_1_0_0__box1 .tabs .current {
				background: #F5F5F5;
				border: none;
			}
			
			.commit_1_0_0__box2__item {
				display: none;
			}
			
			.commit_1_0_0__box2__item.current {
				display: block;
			}
			
			.commit_1_0_0__box2__pic {
				position: relative;
			}
			
			.commit_1_0_0__box2__pic img {
				width: 100%;
			}
			
			.commit_1_0_0__box2__ct {
				position: absolute;
				top: 50%;
				left: 40px;
				width: 50%;
			}
			
			.commit_1_0_0__box2__ct .tt {
				margin-bottom: 30px;
				font-size: 32px;
				color: #000;
				padding-right: 30px;
				padding-top: 10px;
			}
			
			.commit_1_0_0__box2__more {
				padding-top: 15px;
				display: block;
				color: #000;
			}
			
			.commit_1_0_0__box2__more span {
				padding: 10px 10px 10px 0;
			}
			
			.commit_1_0_0__box2__more b,
			.commit_1_0_0__box2__more span,
			.commit_1_0_0__box2__more i {
				color: #fff;
				font-size: 17px;
				font-weight: 600;
				border-radius: 30px;
			}
			
			.commit_1_0_0__box2__more span {
				background: #E43D3B;
			}
			
			.commit_1_0_0__box2__more b {
				background: #0055A4;
				padding: 10px 15px;
			}
			
			.commit_1_0_0__box3 {
				background: #0165CD;
				min-height: 450px;
				margin-top: 70px;
				padding: 20px;
				border-radius: 8px;
				color: #fff;
			}
			
			.commit_1_0_0__box3 h3 {
				text-transform: uppercase;
				font-size: 22px;
				font-weight: 600;
				margin-top: 0;
			}
			
			.commit_1_0_0__box3 select {
				width: 100%;
				text-align: center;
				text-align-last: center;
				padding: 5px;
				background-color: #6DCFF6;
				border: none;
				border-radius: 6px;
				font-size: 18px;
				font-weight: 600;
			}
			
			.commit_1_0_0__box3 option {
				text-align: left;
			}
			
			.commit_1_0_0__box3__item {
				background-color: #fff;
				margin-top: 10px;
				min-height: 350px;
				border-radius: 6px;
			}
			
			.commit_1_0_0__box3__item .scrollbar {
				float: left;
				height: 220px;
				width: 300px;
				overflow-y: scroll;
			}
			
			.commit_1_0_0__box3__item .force-overflow {
				min-height: 320px;
			}
			
			.commit_1_0_0__box3__item #style-1::-webkit-scrollbar-track {
				-webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
				border-radius: 15px;
				background-color: #F5F5F5;
			}
			
			.commit_1_0_0__box3__item #style-1::-webkit-scrollbar {
				width: 5px;
				background-color: #F5F5F5;
			}
			
			.commit_1_0_0__box3__item #style-1::-webkit-scrollbar-thumb {
				border-radius: 15px;
				-webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
				background-color: #0055A4;
			}
			
			.commit_1_0_0__box3__sub {
				display: flex;
				flex-wrap: wrap;
				margin-bottom: 10px;
			}
			
			.commit_1_0_0__box3__sub a:hover {
				color: #0055A4;
			}
			
			.commit_1_0_0__box3__sub .address {
				width: 50%;
			}
			
			.commit_1_0_0__box3__sub .icon__call,
			.commit_1_0_0__box3__sub .icon__time {
				width: 24%;
				padding-top: 22px;
				position: relative;
			}
			
			.commit_1_0_0__box3__sub .icon__call::before {
				background: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAbCAMAAABY1h8eAAAAilBMVEUAAAAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyAjHyB0XzFUAAAALXRSTlMAHQT56dwrSpxvXcGU8u3jVjINypFBJyPUr0U3z7qniHxi2LSsEmQ8FxG5oWgYWmyIAAABTElEQVQoz2WS2WKDIBBFr4DgGrdEszdp1i73/3+vMok1recNjoPDZfDLYt7kZN7MF/hPEpJ6u9ttNRkmf1SQUkcLhR61iDTTYHSV4eplGaxoKjyxM8Z4cF7uEwXEnFkIdcgEUJVDv7svaPpVwrAWmfENcDP68uN3e0sZKbxx7l2n3xWsJmkUTmRqD8yg3nUnhSUQ0XMDPq6Fdod+q5RS0xdg6Z3eAL1Oc9uEShkD1Iwg0qxrCBdzcnSIWCPgEcCezDs8iRnMMhwZoOUagCMZDjl0LD9TrNnCUsI4vVi1cvEcG9pnJS6+paLDiGMr//QExbPWNZF0feBduh0SFvtF+siw1epxT2GT+5MT/03jTz0PCY1WyHAvaIdsH9iCgq7aJQ/jqzy4nEWu9prZy3sOrFPRYTmZBCEo42uFyQxNmEzfyGRu46kZJ36HV34ACq0lLm3MlDMAAAAASUVORK5CYII=') center 0 no-repeat;
				background-size: 100%;
				position: absolute;
				top: 0px;
				left: 10px;
				display: block;
				content: '';
				width: 23px;
				height: 23px;
			}
			
			.commit_1_0_0__box3__sub .icon__call:hover::before {
				background: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAbCAMAAABY1h8eAAAAflBMVEUAAAAAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQ4jNU4AAAAKXRSTlMABB352+krJkqcb11B0sGU8uPLVjIN7a2RujeniHxktBKwYkU8FxGhaI68XzgAAAFKSURBVCjPZZLZdoMwEEPlDQyEHUL2tFna6v9/sGYCh7Tct7GQjpEHM2qzayqyanYbhX9kljT5fp8b0mZ/JF3QJMEhCYlhoRetcxzeRj3QdfMQbZnixZAfsxCQchtB6C2zENd5hNNjTRemjLYXseQJ8I6j/fYTPwomCifuEIiNVYgMSadwJYvozBLKmliMLZBw5AF8XWrjz+GoFasLBuQMmAMQ5KKKGquUc0DPBCK6ew/hw109fQjroXkJB0eyijGRUm9LXKgRcxNmT9LquQS2+wIbxogoZVzfVPXp0x0OjCYnPnKSdYwFH5yat1dWPXl9k8itz3zKbeeGRf0meQpzY9TrP4VDNSZn4zfNmDrMDS2qUOJZM5q7nZJrCqaLc56XV5nKGUT8PBqWb+85cy9Etu1qEwTdppcOqx1asdq+hdXepmtl2fg93vkFd3ohwQqMlhAAAAAASUVORK5CYII=') center 0 no-repeat;
				content: '';
				background-size: 100%;
				position: absolute;
				top: 0px;
				left: 10px;
				display: block;
				width: 23px;
				height: 23px;
			}
			
			.commit_1_0_0__box3__sub .icon__time::before {
				background: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABMAAAAdCAMAAAB/hKeOAAAAmVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjHWqVAAAAMnRSTlMAQICw4dBwUDDwH/ygD8EW+OrUj3UE87SpDOTax5aJYFpNPjgrEwi8pJuTamRVSBuEaZANRuwAAAEDSURBVCjPZc/pcoMgFIbhD4JaBIxb1OyLS/ak5f4vrtCQqu07/GCegZlz4Mr5kmDcU2/Xy5FMN6W+Z7H0Z28Iw6OXVYKvLwkNQ2Voo01boJsB0lzjAIh3SjFv8hM7KbUuAU2AO3XVAI2szc/eoCR5GPMX/jCZGKMTYGbPK6JfdtHME950aI0Otv4h/ZyfpcydBQlMWdVtsuzm7BFbk9LuNHc2FWSfq8VXq7VeOcMp1TzlavgOT3a8id14FuD/fA2xhWgGlnKbbBddb329HQLbAagJ8Z1FzLbCVXAuivFfGmEf07+2EysYy5fBu6oQaWStLdlv3p4aK/KPUVUJXAs9itX4BrT6HVEWJdgIAAAAAElFTkSuQmCC') center 0 no-repeat;
				background-size: 100%;
				position: absolute;
				top: 0px;
				left: 18px;
				display: block;
				content: '';
				width: 16px;
				height: 25px;
			}
			
			.commit_1_0_0__box3__sub .icon__time:hover::before {
				background: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABMAAAAdCAMAAAB/hKeOAAAAilBMVEUAAAAAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaQAVaRd3ZgyAAAALXRSTlMAQICwT+BwMND78R/AoBcPBu7jqJFzYQvUzYpa9tnHaT44KxPotpuWlXpUSIS7SVg/AAAA/klEQVQoz2XQ13KEIBSA4aOLRlBExd7L9g3v/3o5ZEmU5B8vnG/oYCpSzwG7UJX3wZK4vahnS3mR/EAYRkEuaXrLUzcMBVKrsBIgwTEcfykBoJ0QWXP6LpNC3C4ACrfrXNMC4EbaqmsT7J3TF5qf+cd4iuaecAf9vXPU2+4qa2gQH21VpPTn+rO6cv4wRs6A5TJp87w09uq1ca7vVBmLqUMKkU0b3mM0BnJQac3EcRzEXlTSzj4L9u98q6MLYT1YzXR8y6rd9nabiW4GWBzHNxZ5uhEmyhjt7bn4oKR//LWOjoBWDE9ikozWkbbt5P3WEBeNFR9WEleamLLyFvgCk2Aa9ErwR34AAAAASUVORK5CYII=') center 0 no-repeat;
				background-size: 100%;
				position: absolute;
				top: 0px;
				left: 18px;
				display: block;
				content: '';
				width: 16px;
				height: 25px;
			}
			
			@media (max-width: 1024px) {
				.commit_1_0_0__box1 .tabs a {
					text-align: center;
					padding: 10px;
				}
				.commit_1_0_0__box1 .tabs a img {
					width: 60%;
				}
				.commit_1_0_0__box2__ct .tt {
					font-size: 24px;
				}
				.commit_1_0_0__box3 {
					min-height: 400px;
					margin-top: 60px;
				}
				.commit_1_0_0__box3 h3 {
					font-size: 20px;
				}
				.commit_1_0_0__box3__item {
					min-height: 250px;
				}
				.commit_1_0_0__box3__item .scrollbar {
					width: 235px;
				}
				.commit_1_0_0__box3__item #style-1::-webkit-scrollbar {
					width: 3px;
				}
				.commit_1_0_0__box3__sub {
					margin-bottom: 20px;
				}
				.commit_1_0_0__box3__sub .address {
					width: 100%;
				}
				.commit_1_0_0__box3__sub .icon__call,
				.commit_1_0_0__box3__sub .icon__time {
					width: 50%;
					text-align: center;
				}
				.commit_1_0_0__box3__sub .icon__call::before,
				.commit_1_0_0__box3__sub .icon__time::before {
					left: 40%;
				}
				.commit_1_0_0__box3__sub .icon__call:hover::before,
				.commit_1_0_0__box3__sub .icon__time:hover::before {
					left: 40%;
				}
			}
			
			@media (max-width: 812px) {
				.commit_1_0_0__box2__ct .tt {
					margin-bottom: 15px;
					font-size: 16px;
					padding-top: 20px;
				}
				.commit_1_0_0__box2__ct i {
					font-size: 13px;
				}
				.commit_1_0_0__box3 {
					min-height: 300px;
					padding: 10px;
				}
				.commit_1_0_0__box3 h3 {
					font-size: 14px;
				}
				.commit_1_0_0__box3 select {
					padding: 4px;
					font-size: 14px;
				}
				.commit_1_0_0__box3__item {
					min-height: 220px;
				}
				.commit_1_0_0__box3__item .scrollbar {
					width: 163px;
					height: 190px;
				}
				.commit_1_0_0__box3__sub {
					font-size: 13px;
				}
			}
			
			@media (max-width: 414px) {
				.commit_1_0_0__title h2 {
					font-size: 22px;
					padding: 20px 0 5px;
					text-align: center;
				}
				.commit_1_0_0__box2__ct {
					position: relative;
					top: auto;
					left: auto;
					width: 100%;
					text-align: center;
				}
				.commit_1_0_0__box2__ct .tt {
					text-align: left;
					padding-left: 15px;
					width: 50%;
					margin-top: -150px;
					margin-bottom: 0px;
					height: 160px;
				}
				.commit_1_0_0__box3 {
					width: 90%;
					margin: 30px auto;
				}
				.commit_1_0_0__box3 h3 {
					font-size: 25px;
				}
				.commit_1_0_0__box3 select {
					padding: 8px;
					font-size: 18px;
				}
				.commit_1_0_0__box3__item {
					min-height: 400px;
				}
				.commit_1_0_0__box3__item .scrollbar {
					width: 100%;
					height: 200px;
				}
				.commit_1_0_0__box3__sub {
					font-size: 14px;
				}
				.commit_1_0_0__box3__sub .address {
					width: 40%;
				}
				.commit_1_0_0__box3__sub .icon__call,
				.commit_1_0_0__box3__sub .icon__time {
					width: 30%;
					text-align: center;
				}
				.commit_1_0_0__box3__sub .icon__call::before,
				.commit_1_0_0__box3__sub .icon__time::before {
					left: 40%;
				}
				.commit_1_0_0__box3__sub .icon__call:hover::before,
				.commit_1_0_0__box3__sub .icon__time:hover::before {
					left: 40%;
				}
			}
			
			@media (max-width: 375px) {
				.commit_1_0_0__box2__more span,
				.commit_1_0_0__box2__more b {
					font-size: 14px;
				}
				.commit_1_0_0__box3 h3 {
					font-size: 20px;
				}
				.commit_1_0_0__box3 select {
					padding: 5px;
					font-size: 16px;
				}
			}
			
			@media (max-width: 360px) {
				.commit_1_0_0__box2__ct .tt {
					width: 60%;
					font-size: 15px;
					margin-top: -130px;
					height: 140px;
				}
				.commit_1_0_0__box3__item {
					min-height: 300px;
				}
			}
			
			@media (max-width: 320px) {
				.commit_1_0_0__title h2 {
					font-size: 20px;
				}
				.commit_1_0_0__box2__ct .tt {
					font-size: 14px;
				}
				.commit_1_0_0__box3 h3 {
					font-size: 18px;
				}
				.commit_1_0_0__box3__item {
					min-height: 250px;
				}
			}
			/*# sourceMappingURL=commit_1_0_0.css.map */
		</style>

        ";
		add_action('wp_footer', 'commit_1_0_0');
		function commit_1_0_0(){ 
			echo '
				<script>
					$(".tabs .tab ").click(function() {
						var tab_id = $(this).attr("data-tab");
						$(".commit_1_0_0__box2__item").removeClass("current");
						$(".tab").removeClass("current");
				
						$(this).addClass("current");
						$("#" + tab_id).addClass("current");
					})
				
					$(".tab-content").hide();
					$("#tab-1").show();
				
					$("#select-box").change(function() {
						dropdown = $("#select-box").val();
						$(".tab-content").hide();
						$("#" + "tab-" + dropdown).show();
					});
				
					jQuery(document).ready(function() {
						jQuery(".scrollbar-light").scrollbar();
					});
					
					
				</script>
            ';           
        };
			
	}
	
?>



<?php include(locate_template('Module/Popup/popup_regist_1_0_1/content-popup_regist_1_0_1.php')); ?>
<?php include(locate_template('Module/Popup/popup_call_1_1_0/content-popup_call_1_1_0.php')); ?>
<section class="commit_1_0_0">
	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<div class="commit_1_0_0__title">
					<h2><?php echo $field['title']; ?></h2>
				</div>
				<div class="commit_1_0_0__box1">
					<div class="tabs">
						<?php
							$i = 1;
							foreach($field['info1'] as $key => $value):
								$data = explode("\n",  $value["content1"]);
								if($key == 0 ):
									$current = 'current';
								else: 
									$current = '';
								endif;
								echo'
									<a data-tab="s'.$i.'" class="tab '.$current.'">
										<img src="'.$data[0].'" alt="">
									</a>
								';
								$i++;
							endforeach;
						?>
					</div>
				</div>
				<div class="commit_1_0_0__box2">
						<?php
							$i = 1;
							foreach($field['info1'] as $key => $value):
								$data = explode("\n",  $value["content1"]);
								if($key == 0 ):
									$current = 'current';
								else: 
									$current = '';
								endif;
								echo'
									
									<div class="commit_1_0_0__box2__item '.$current.'" id="s'.$i.'">
										<div class="commit_1_0_0__box2__pic">
											<img src="'.$data[4].'" alt="">
										</div>
										<div class="commit_1_0_0__box2__ct">
											<div class="tt">'.$data[1].'</div>
											<i>'.$data[2].'</i><br>
											<a href="'.$data[3].'" class="commit_1_0_0__box2__more">
												<span><b>Đăng Ký Tư Vấn</b> <i class="icon-angle-double-right"></i></span>
											</a>
										</div>
									</div>
								';
								$i++;
							endforeach;
						?>
				</div>
			</div>
			<div class="col-md-4">
				<div class="commit_1_0_0__box3">
					<div class="commit_1_0_0__box3__tt">
						<h3><?php echo $field['contact_title']; ?></h3>
						<div class="commit_1_0_0__box3__select">
							<select id="select-box">
								<?php
									$i = 1;
									foreach($field['contact_info'] as $key => $value):
										echo'
											<option value="'.$i.'">'.$value['contact_city_name'].'</option>
										';
										$i++;
									endforeach;
								?>
							</select>
						</div>
						<div class="commit_1_0_0__box3__list">
							<?php
								$i = 1;
								
								foreach($field['contact_info'] as $value_0):
								
									echo'
									<div class="commit_1_0_0__box3__item tab-content" id="tab-'.$i.'">
                                    	<div class="scrollbar" id="style-1">
                                        	<div class="force-overflow">
									';
											
												foreach($value_0 as $value_1):
													foreach($value_1 as $key => $value):
													$data2 = explode("\n",  $value["content"]);
													$x = $data2[0];
													echo'
														
														<div class="commit_1_0_0__box3__sub">
															<a href="'.$data2[1].'" class="address">'.$x.'</a>
															<a class="icon__call popup_call"> Hotline</a>
															<a class="icon__time popup_regist" onclick="myFunction(document.getElementById(\'local-'.$i.$key.'\').textContent)"> Lịch hẹn</a>
															<div id = "local-'.$i.$key.'" style: display:none;>'.$x.'</div>

														</div>
														<script>
														function myFunction(text) {
														  document.getElementById("itext").innerHTML = "Đặt lịch hẹn tại: "+text;
														}
														</script>
													';
												endforeach;
											endforeach;
									echo'
											</div>
											</div>
										</div>
									';
									$i++;
								
								endforeach;
							?>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>
</section>

