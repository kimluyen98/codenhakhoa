<?php 
    $path = get_template_directory_uri();
    $path = $path.'/Module/Header/header_6_0_0'; 
    if($check == 0){
        $css_inline .= '
            <style>
                .header_6_0_0 {
                    font-family: -apple-system, system-ui, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
                }
                
                a {
                    text-decoration: none;
                }
                
                .header_6_0_0_box_2__menu__menuSub .arr::before,
                .header_6_0_0_box_2__menu__menuSubBox ul li a::after {
                    font-family: "fontello";
                    font-style: normal;
                    font-weight: 400;
                    speak: none;
                    display: inline-block;
                    text-decoration: inherit;
                    width: 1em;
                    margin-right: .2em;
                    text-align: center;
                    font-variant: normal;
                    text-transform: none;
                    line-height: 1em;
                    margin-left: .2em;
                    -webkit-font-smoothing: antialiased;
                    -moz-osx-font-smoothing: grayscale;
                }
                
                .header_6_0_0 {
                    position: fixed;
                    z-index: 9;
                    width: 100%;
                    top: 0;
                }
                
                .header_6_0_0_box_top {
                    background: url('.$path.'/images/boxtop-bg.jpg) center bottom no-repeat;
                    position: relative;
                    z-index: 2;
                    width: 100%;
                    min-height: 50px;
                }
                
                .header_6_0_0_box_top__new {
                    text-align: center;
                    padding-top: 15px;
                }
                
                .header_6_0_0_box_top__newlabel {
                    font-weight: 400;
                    color: #fff;
                    font-weight: 600;
                    text-transform: uppercase;
                }
                
                @media (max-width: 1366px) {
                    .header_6_0_0_box_top__newlabel {
                        font-size: 14px;
                    }
                }
                
                @media (max-width: 1024px) {
                    .header_6_0_0_box_top__newlabel {
                        line-height: 8px;
                        font-size: 11px;
                    }
                }
                
                @media (max-width: 812px) {
                    .header_6_0_0_box_top__newlabel {
                        display: none;
                    }
                }
                
                .header_6_0_0_box_top__newlabel.lb1 {
                    display: none;
                }
                
                @media (max-width: 812px) {
                    .header_6_0_0_box_top__newlabel.lb1 {
                        display: block;
                    }
                }
                
                .header_6_0_0_box_1 {
                    background-color: #fff;
                }
                
                .header_6_0_0_box_1 .container {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                }
                
                .header_6_0_0_box_1_left,
                .header_6_0_0_box_1_right {
                    display: flex;
                    align-items: center;
                }
                
                .header_6_0_0_box_1__logo {
                    height: 90px;
                    padding-top: 15px;
                    margin-right: 50px;
                    position: relative;
                }
                
                .header_6_0_0_box_1__title {
                    color: #00ABE5;
                }
                
                .header_6_0_0_box_1__title h2 {
                    text-transform: uppercase;
                    font-size: 15px;
                    font-weight: 600;
                    margin: 5px 0 0;
                }
                
                .header_6_0_0_box_1__title p {
                    text-transform: uppercase;
                    font-size: 15px;
                    font-weight: 600;
                }
                
                .header_6_0_0_box_1__address {
                    position: relative;
                }
                
                .header_6_0_0_box_1__address ul {
                    list-style: none;
                }
                
                .header_6_0_0_box_1__address ul::before {
                    background: url('.$path.'/images/icon1.png) 0 center no-repeat;
                    content: "";
                    position: absolute;
                    top: 0;
                    left: -25px;
                    width: 60px;
                    height: 60px;
                }
                
                .header_6_0_0_box_1__address ul li {
                    color: #000;
                    font-size: 15px;
                }
                
                .header_6_0_0_box_1__address ul li b {
                    font-size: 18px;
                }
                
                .header_6_0_0_box_1__call {
                    margin-left: 25px;
                    text-align: center;
                    position: relative;
                }
                
                .header_6_0_0_box_1__call ul {
                    list-style: none;
                }
                
                .header_6_0_0_box_1__call ul::before {
                    background: url('.$path.'/images/icon2.png) 0 center no-repeat;
                    content: "";
                    position: absolute;
                    top: 15px;
                    left: -3px;
                    width: 40px;
                    height: 40px;
                }
                
                .header_6_0_0_box_1__call ul li {
                    color: #000;
                }
                
                .header_6_0_0_box_1__call ul li a {
                    color: #000;
                    font-weight: bold;
                    font-size: 18px;
                }
                
                .header_6_0_0_box_1__regtv {
                    font-size: 16px;
                    display: block;
                    color: #fff;
                    background: #0056A4;
                    text-align: center;
                    padding: 5px 20px;
                    border-radius: 40px;
                    margin: 0 15px;
                }
                
                .header_6_0_0_box_1__button {
                    background: #6DCFF6;
                    outline: none;
                    color: #fff;
                    cursor: pointer;
                    border-radius: 100%;
                    padding: 12px;
                    border: none;
                }
                
                .header_6_0_0_box_1 .iconMid {
                    display: none;
                }
                
                .header_6_0_0_box_2 {
                    background-color: #EBECF0;
                    padding: 0;
                }
                
                .header_6_0_0_box_2 .container {
                    display: flex;
                    align-items: center;
                }
                
                .header_6_0_0_box_2__logosb {
                    display: none;
                }
                
                .header_6_0_0_box_2__logosb img {
                    max-width: 90%;
                    margin: 20px 0 0;
                }
                
                .header_6_0_0_box_2__menu {
                    display: flex;
                    list-style: none;
                    padding: 0;
                    margin: 0;
                }
                
                .header_6_0_0_box_2__menu__menuSub {
                    display: flex;
                    align-items: center;
                    border-top: 3px solid #EBECF0;
                    padding: 8px 12px;
                }
                
                .header_6_0_0_box_2__menu__menuSub .menu-icon {
                    display: none;
                    position: absolute;
                    right: 0;
                    top: 0;
                    padding: 10px;
                    width: 100%;
                    height: 100%;
                    text-align: right;
                }
                
                .header_6_0_0_box_2__menu__menuSub .arr::before {
                    content: "\e88f";
                    display: none;
                    position: absolute;
                    bottom: 5px;
                    left: 40px;
                    text-align: center;
                    color: #f16749;
                }
                
                .header_6_0_0_box_2__menu__menuSub.icon-homes {
                    border-top: none;
                }
                
                .header_6_0_0_box_2__menu__menuSub.icon-homes:hover {
                    border-top: none;
                }
                
                .header_6_0_0_box_2__menu__menuSub:hover {
                    border-top: 3px solid #0056A2;
                }
                
                .header_6_0_0_box_2__menu__menuSub:hover .header_6_0_0_box_2__menu__menuSubBox {
                    display: block;
                    animation: opac 0.4s;
                }
                
                .header_6_0_0_box_2__menu__menuSub:hover>a {
                    color: #0056A2;
                }
                
                .header_6_0_0_box_2__menu__menuSubBox {
                    display: none;
                    position: absolute;
                    width: 100%;
                    right: 0px;
                    top: 60px;
                    padding: 15px 25px;
                    font-size: 1rem;
                    color: #000;
                    text-align: left;
                    list-style: none;
                    background-color: #fff;
                    -webkit-background-clip: padding-box;
                    background-clip: padding-box;
                    border: 1px solid rgba(0, 0, 0, 0.15);
                    box-shadow: 0 0 2px rgba(0, 0, 0, 0.2);
                    border-radius: 15px;
                }
                
                .header_6_0_0_box_2__menu__menuSubBox ul {
                    list-style: none;
                    padding-left: 0;
                }
                
                .header_6_0_0_box_2__menu__menuSubBox ul li {
                    border-bottom: 1px solid #f1f1f1;
                    padding-bottom: 5px;
                    margin-bottom: 5px;
                    position: relative;
                }
                
                .header_6_0_0_box_2__menu__menuSubBox ul li a {
                    color: #000;
                    transition: 0.1s;
                    border: none;
                    font-size: 15px;
                }
                
                .header_6_0_0_box_2__menu__menuSubBox ul li a:hover {
                    color: #0056A4;
                    font-weight: 600;
                }
                
                .header_6_0_0_box_2__menu__menuSubBox ul li a::after {
                    content: "\e88d";
                    display: block;
                    position: absolute;
                    right: 0;
                    top: 5px;
                }
                
                .header_6_0_0_box_2__menu__menuSubBox h4 {
                    color: #307DAD;
                    text-transform: uppercase;
                    font-size: 16px;
                    margin-top: 10px;
                }
                
                .header_6_0_0_box_2__menu__title {
                    padding: 0px 5px;
                    display: block;
                    font-size: 14px;
                    cursor: pointer;
                    text-align: center;
                    position: relative;
                    font-weight: 600;
                    text-transform: uppercase;
                }
                
                .header_6_0_0_box_2__menu .mntt {
                    color: #fff;
                    font-size: 15px;
                    padding: 5px 0;
                    text-transform: uppercase;
                    border-bottom: 1px dotted #355b7d;
                    position: relative;
                    margin-bottom: 10px;
                }
                
                .header_6_0_0_box_2__menu .mntt::before {
                    content: "";
                    display: block;
                    position: absolute;
                    left: 0;
                    bottom: -2px;
                    width: 70px;
                    height: 3px;
                    background: #fff;
                }
                
                .header_6_0_0_box_2__social {
                    margin-left: 100px;
                }
                
                .header_6_0_0_box_2__social a {
                    margin: 0 2px;
                }
                
                .header_6_0_0_box_2.active {
                    display: block;
                    animation: animateleft 0.4s;
                }
                
                .header_6_0_0_box_3 {
                    background: rgba(0, 0, 0, 0.8);
                    width: 100%;
                    height: 100%;
                    content: "";
                    display: none;
                    position: fixed;
                    top: 0;
                    left: 0;
                    z-index: 2;
                    animation: opac 0.4s;
                }
                
                .header_6_0_0_box_3.active {
                    display: block;
                }
                
                .header_6_0_0.menufix {
                    background: #fff;
                }
                
                .header_6_0_0.menufix .header_6_0_0_box_1 {
                    display: block;
                }
                
                .header_6_0_0.menufix .header_6_0_0_box_2 {
                    background-color: #fff;
                }
                
                .header_6_0_0.menufix .header_6_0_0_box_2__menu {
                    margin: 10px 0;
                }
                
                .header_6_0_0.menufix .header_6_0_0_box_2__menu__menuSub {
                    border: none;
                }
                
                .header_6_0_0.menufix .header_6_0_0_box_2__menu__menuSub:hover {
                    border: none;
                }
                
                .header_6_0_0.menufix .header_6_0_0_box_2__menu__title {
                    color: #000;
                }
                
                @media (max-width: 1024px) {
                    .header_6_0_0 {
                        background-color: #fff;
                        height: 65px;
                    }
                    .header_6_0_0 .container {
                        padding: 0;
                    }
                    .header_6_0_0_box_top {
                        min-height: 40px;
                    }
                    .header_6_0_0_box_top__newlabel {
                        font-size: 15px;
                    }
                    .header_6_0_0_box_1 .container {
                        justify-content: center;
                        position: relative;
                    }
                    .header_6_0_0_box_1__title {
                        display: none;
                    }
                    .header_6_0_0_box_1_right {
                        display: none;
                    }
                    .header_6_0_0_box_1__logo {
                        text-align: center;
                        width: 100px;
                        margin: 0 auto;
                        position: relative;
                        display: block;
                    }
                    .header_6_0_0_box_1__logo img {
                        position: absolute;
                        top: 10px;
                        left: -40px;
                        height: 60px;
                    }
                    .header_6_0_0_box_1__logo::after {
                        display: none;
                    }
                    .header_6_0_0_box_1__search__icon {
                        display: none;
                    }
                    .header_6_0_0_box_1 .iconMid {
                        display: block;
                    }
                    .header_6_0_0_box_1 .siteHeaderNav {
                        position: absolute;
                        left: 0;
                        color: #025A7E;
                        font-size: 35px;
                    }
                    .header_6_0_0_box_1 .siteHeaderCall {
                        position: absolute;
                        right: 0;
                        color: #fff;
                        font-size: 18px;
                        width: 100px;
                        height: 60px;
                        text-align: center;
                        line-height: 0px;
                        border-radius: 5px;
                    }
                    .header_6_0_0_box_1 .siteHeaderCall img {
                        width: auto;
                    }
                    .header_6_0_0_box_1 .siteHeaderCall button {
                        height: 38px;
                        width: 38px;
                        line-height: 1.5;
                        border-radius: 100%;
                        border: 2px solid #0056A2;
                        background: #fff;
                    }
                    .header_6_0_0_box_1 .siteHeaderCall button i {
                        color: #0056A2;
                    }
                    .header_6_0_0_box_2 {
                        display: none;
                        width: 270px;
                        background: #fff;
                        position: fixed;
                        height: 100%;
                        left: 0;
                        top: 0;
                        z-index: 3;
                        overflow: auto;
                        padding-bottom: 20px;
                    }
                    .header_6_0_0_box_2 .container {
                        display: block;
                        width: 270px;
                    }
                    .header_6_0_0_box_2__logosb {
                        text-align: center;
                    }
                    .header_6_0_0_box_2__menu {
                        display: block;
                        margin: 30px 0;
                    }
                    .header_6_0_0_box_2__menu__menuSub {
                        position: relative;
                        padding: 7px 0;
                        border-bottom: 1px dashed #ccc;
                        border-top: none;
                    }
                    .header_6_0_0_box_2__menu__menuSub:nth-child(1) {
                        display: none;
                    }
                    .header_6_0_0_box_2__menu__menuSub:last-child {
                        border: none;
                    }
                    .header_6_0_0_box_2__menu__menuSub .menu-icon {
                        display: block;
                        font-size: 11px;
                        color: #000;
                    }
                    .header_6_0_0_box_2__menu__menuSub .arr::before {
                        display: none;
                    }
                    .header_6_0_0_box_2__menu__menuSub a {
                        border-top: none;
                    }
                    .header_6_0_0_box_2__menu__menuSub:hover {
                        border-top: none;
                        display: block;
                        animation: opac 0.4s;
                        transition: 0.4s;
                    }
                    .header_6_0_0_box_2__menu__menuSub:hover>a {
                        color: #0056A2;
                        border-top: none;
                    }
                    .header_6_0_0_box_2__menu__menuSubBox {
                        position: inherit;
                        top: 0;
                        right: 0;
                        border-radius: 0;
                        width: 100%;
                        padding: 10px;
                        background-color: #002E60;
                        border: none;
                    }
                    .header_6_0_0_box_2__menu__menuSubBox .col-lg-4,
                    .header_6_0_0_box_2__menu__menuSubBox .col-lg-6 {
                        flex: 0 0 100%;
                        max-width: 100%;
                    }
                    .header_6_0_0_box_2__menu__menuSubBox ul li {
                        border-bottom: 1px dashed #ccc;
                    }
                    .header_6_0_0_box_2__menu__menuSubBox ul li a {
                        color: #fff;
                        padding: 0;
                        border-top: none !important;
                        font-size: 14px;
                    }
                    .header_6_0_0_box_2__menu__menuSubBox h4 {
                        font-size: 14px;
                        color: #fff;
                    }
                    .header_6_0_0_box_2__menu__menuSubBox h4::after {
                        content: "";
                        border-bottom: 2px solid #307DAD;
                        display: block;
                        width: 70px;
                        padding-top: 5px;
                    }
                    .header_6_0_0_box_2__menu__title {
                        text-align: left;
                        padding: 5px 10px;
                    }
                    .header_6_0_0_box_2__menu__title br {
                        display: none;
                    }
                    .header_6_0_0_box_2__menu .mntt {
                        margin-bottom: 3px;
                        margin-top: 3px;
                        font-size: 14px;
                        color: #f69679;
                    }
                    .header_6_0_0_box_2__menu .mntt::before {
                        display: none;
                    }
                    .header_6_0_0_box_2__social {
                        margin-left: 0;
                        text-align: center;
                    }
                    .header_6_0_0_box_2__logosb {
                        display: block;
                    }
                }
                
                @media (max-width: 812px) {
                    .header_6_0_0_box_top {
                        background: url('.$path.'/images/boxtop-bg-m.jpg) center bottom no-repeat;
                        min-height: 35px;
                    }
                    .header_6_0_0_box_top__new {
                        padding-top: 12px;
                    }
                    .header_6_0_0_box_top__newlabel {
                        font-size: 13px;
                    }
                }
                
                @media (max-width: 414px) {
                    .header_6_0_0_box_1__logo img {
                        top: 20px;
                        left: -30px;
                        height: 50px;
                    }
                    .header_6_0_0_box_1__title {
                        color: #62D4FF;
                        position: absolute;
                        top: 90px;
                        display: flex;
                        left: 0;
                        width: 100%;
                        justify-content: center;
                        align-items: center;
                        background-color: #131439;
                        padding: 5px 0;
                    }
                    .header_6_0_0_box_1__title h2 {
                        font-size: 13px;
                        margin-top: 0;
                        padding-right: 10px;
                        margin-right: 10px;
                        border-right: 1px solid #62D4FF;
                    }
                    .header_6_0_0_box_1__title p {
                        margin-bottom: 0;
                    }
                    .header_6_0_0_box_1 .siteHeaderNav {
                        left: 10px;
                        font-size: 30px;
                    }
                    .header_6_0_0_box_1 .siteHeaderCall {
                        right: 10px;
                        height: 40px;
                    }
                    .header_6_0_0_box_1 .siteHeaderCall img {
                        width: 100%;
                    }
                    .header_6_0_0_box_2__menu__menuSubBox ul li {
                        font-size: 13px;
                    }
                }
                
                @media (max-width: 375px) {
                    .header_6_0_0_box_1 .siteHeaderNav {
                        left: 10px;
                        font-size: 28px;
                    }
                    .header_6_0_0_box_1 .siteHeaderCall {
                        right: -10px;
                        height: 30px;
                        font-size: 16px;
                    }
                    .header_6_0_0_box_1 .siteHeaderCall img {
                        width: 80%;
                    }
                    .header_6_0_0_box_1 .siteHeaderCall button {
                        height: 30px;
                        width: 30px;
                        line-height: 0;
                        margin-left: -25px;
                    }
                }
                
                @media (max-width: 320px) {
                    .header_6_0_0_box_1 .siteHeaderCall {
                        right: -15px;
                    }
                }
                /*# sourceMappingURL=header_6_0_0.css.map */
            </style>
        ';

        add_action('wp_footer', 'header_6_0_0');
        function header_6_0_0(){ 
            echo '
                <script>
                function layoutHandler(){window.innerWidth<1025&&$(".mn1,.mn2,.mn3,.mn4,.mn5,.mn6,.mn7,.mn8,.mn9").click((function(){$(this).parent().find(".header_6_0_0_box_2__menu__menuSubBox").toggle()})),window.innerWidth<1025&&$(".LP .siteHeaderMain a").click((function(){$(".LP .siteHeaderMain").removeClass("active"),$(".siteHeader-bg").removeClass("active")}))}layoutHandler(),$(".header_6_0_0_box_2__menu__menuSub .menu-icon").click((function(){$(this).parent().find(".header_6_0_0_box_2__menu__menuSubBox").toggle(),1==$(this).hasClass("icon-plus")?($(this).addClass("icon-minus"),$(this).removeClass("icon-plus")):($(this).removeClass("icon-minus"),$(this).addClass("icon-plus"))})),$(".siteHeaderNav").click((function(){$(".header_6_0_0_box_2").addClass("active"),$(".header_6_0_0_box_3").addClass("active")})),$(".header_6_0_0_box_3").click((function(){$(".header_6_0_0_box_2").removeClass("active"),$(".header_6_0_0_box_3").removeClass("active")}));
                </script>
            ';           
        };
    }
?> 


<header class="header_6_0_0">

<div class="header_6_0_0_box">
    <div class="header_6_0_0_box_top">
        <div class="header_6_0_0_box_top__new">
            <div class="header_6_0_0_box_top__newlabel">
                <?php
                    $value = $field['about'];
                    $data = explode("\n",  $value);
                    echo ' '.$data[0].' ';
                ?>
            </div>
            <div class="header_6_0_0_box_top__newlabel lb1">
                <?php
                    $value = $field['about'];
                    $data = explode("\n",  $value);
                    echo ' '.$data[1].' ';
                ?>
            </div>
        </div>
    </div>

    <div class="header_6_0_0_box_1">

        <div class="container">

            <div class="header_6_0_0_box_1_left">
                <div class="header_6_0_0_box_1__logo">
                    <a href="">
                        <img src="<?php echo $path; ?>/images/logo.png" alt="">
                    </a>
                </div>
            </div>
            <div class="header_6_0_0_box_1_right">
                <div class="header_6_0_0_box_1__address">
                    <?php
						$value = $field['col1'];
						$data = explode("\n",  $value);
                         echo '
                            <ul>
                                <li>'.$data[0].'</li>
                                <li><b>'.$data[1].'</b></li>
                            </ul>
                         '; 
					?>
                     
                </div>
                <div class="header_6_0_0_box_1__call">
                    <?php
						$value = $field['col2'];
						$data = explode("\n",  $value);
                         echo '
                            <ul>
                                <li>'.$data[0].'</li>
                                <li><b>'.$data[1].'</b></li>
                            </ul>
                         '; 
					?>
                </div>
                <div class="header_6_0_0_box_1__regtv">
                    <a href="" class="header_6_0_0_box_1__regtv">Đặt Lịch Hẹn</a>
                </div>
                <div class="header_6_0_0_box_1__search">
                    <button class="header_6_0_0_box_1__button"><i class="icon-search"></i></button>
                </div>
            </div>

            <div class="iconMid siteHeaderNav"><i class="icon-menu"></i></div>
            <a href="#" class="iconMid siteHeaderCall btnnkhotline">
                <div style="float: left;">
                    <img src="<?php echo $path; ?>/images/icon2.png" alt="" class="popup_call">
                </div>
                <button><i class="icon-search"></i></button>

            </a>
        </div>
    </div>

    <div class="header_6_0_0_box_2">
        <div class="container">
            <a href="#" class="header_6_0_0_box_2__logosb"><img src="<?php echo $path; ?>/images/logo.png" alt=""></a>

            <ul class="header_6_0_0_box_2__menu">
            <li class="header_6_0_0_box_2__menu__menuSub icon-homes">
                <a href="#" class="header_6_0_0_box_2__menu__title arr icon-home"><img src="<?php echo $path; ?>/images/icon-home.png" alt=""></a>
                <a href="#" class="header_6_0_0_box_2__menu__title arr icon-home popup_call"><img src="<?php echo $path; ?>/images/icon-call.png" alt=""></a>
            </li>
            <?php
                foreach( $field as $key2 => $value): 
                    $j=1;
                    foreach( $value as $key3 => $list):
                        $main_tt = explode("\n",  $list["title"]);
                        if( $list['acf_fc_layout'] == 'menu_don' ):
                            echo '
                                <li class="header_6_0_0_box_2__menu__menuSub">
                                    <a href="'.$main_tt[1].'"class="header_6_0_0_box_2__menu__title arr">'.$main_tt[0].'</a>
                                </li>
                            ';
                       
                        elseif ( $list['acf_fc_layout'] == 'menu_sub_full' ):
                            $main_tt = explode("\n",  $list["title"]);
                            echo '
                                <li class="header_6_0_0_box_2__menu__menuSub"><a href="'.$main_tt[1].'"class="header_6_0_0_box_2__menu__title arr">'.$main_tt[0].'</a>
                                    <i class="icon-plus menu-icon"></i>
                                    <div class="header_6_0_0_box_2__menu__menuSubBox">
                                            <div class="box">
                                                <div class="row">
                                            ';
                                            $so_cot = $main_tt[2];
                                            if ($so_cot == ''):
                                                $so_cot = '1';
                                            endif;
                                            
                                            $main_ct = explode("&nbsp;",  $list["col1"]);
                                            if($so_cot == 1):
                                                $i = 12;
                                                for($j = 0; $j < 1; $j++){
                                                    echo'
                                                        <div class="col-lg-'.$i.'">
                                                            '.$main_ct[$j].'
                                                        </div>
                                                    ';
                                                }
                                            elseif($so_cot == 2):
                                                $i = 6;
                                                for($j = 0; $j < 2; $j++){
                                                    echo'
                                                        <div class="col-lg-'.$i.'">
                                                            '.$main_ct[$j].'
                                                        </div>
                                                    ';
                                                }

                                            elseif($so_cot == 3):
                                                $i = 4;
                                                for($j = 0; $j < 3; $j++){
                                                    echo'
                                                        <div class="col-lg-'.$i.'">
                                                            '.$main_ct[$j].'
                                                        </div>
                                                        ';
                                                }
                                            elseif($so_cot == 4):
                                                $i = 3;
                                                for($j = 0; $j < 4; $j++){
                                                    echo'
                                                        <div class="col-lg-'.$i.'">
                                                            '.$main_ct[$j].'
                                                        </div>
                                                    ';
                                                }
                                                
                                            elseif($so_cot == 'auto'):
                                                echo'
                                                    '.$list["col1"].'                                                
                                                ';

                                            endif;
                            echo'
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            ';
                        endif;
                        $j++;
                    endforeach;
                endforeach;
            ?>

            </ul>
            <div class="header_6_0_0_box_2__social">
                <?php
                 $value = $field['about'];
                 $data = explode("\n",  $value);
                 echo ' 
                    <a href="'.$data[2].'">
                        <img src="'.$path.'/images/fb.png" alt="">
                    </a>
                    <a href="'.$data[3].'">
                        <img src="'.$path.'/images/yt.png" alt="">
                    </a>
                    <a href="'.$data[4].'">
                        <img src="'.$path.'/images/zalo.png" alt="">
                    </a>
                    <a href="'.$data[5].'">
                        <img src="'.$path.'/images/insta.png" alt="">
                    </a>
                 ';
                   

                ?>
                
            </div>
        </div>
    </div>

    <div class="header_6_0_0_box_3"></div>
</div>

</header>



