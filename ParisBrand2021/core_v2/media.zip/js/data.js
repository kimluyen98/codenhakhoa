let data = {
    titlePage : 'SCI FRAMEWORK',
    navMenu : [
        {
            name : 'Flex',
            link : 'flex.html'
        },
        {
            name : 'Gird',
            link : 'gird.html'
        },
        {
            name : 'Table',
            link : 'table.html'
        },
        {
            name : 'Media Object',
            link : 'media.html'
        },
        {
            name : 'Accordion',
            link : 'accordion.html'
        },
        {
            name : 'Tiny Slider',
            link : 'slider.html'
        },
        {
            name : 'Tabs',
            link : 'tabs.html'
        },
        {
            name : 'Lazyload',
            link : 'lazy.html'
        },
        {
            name : 'Modal',
            link : 'modal.html'
        },
        {
            name : 'Icon Font',
            link : 'icon.html'
        },        
        {
            name : 'Icon Symbol',
            link : 'symbols.html'
        },        
    ],

}
